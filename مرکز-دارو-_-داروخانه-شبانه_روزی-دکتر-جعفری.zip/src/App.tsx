import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { HeroCarousel } from './components/HeroCarousel';
import { TrendingBar } from './components/TrendingBar';
import { EditorsPick } from './components/EditorsPick';
import { VideoSection } from './components/VideoSection';
import { DoctorInterviews } from './components/DoctorInterviews';
import { DrugDirectory } from './components/DrugDirectory';
import { ComparisonSections } from './components/ComparisonSections';
import { LatestArticles } from './components/LatestArticles';
import { NewsletterBanner } from './components/NewsletterBanner';
import { ArticleView } from './components/ArticleView';
import { CategoryView } from './components/CategoryView';
import { AIChatBot } from './components/AIChatBot';
import { Modals } from './components/Modals';
import { Footer } from './components/Footer';
import { Toast } from './components/Toast';

import { ARTICLES, VIDEOS, DRUGS, INTERVIEWS, OFFER_PRODUCTS, CATEGORIES } from './data';
import { Drug, Article } from './types';

export default function App() {
  const [currentView, setCurrentView] = useState<'home' | 'category' | 'article' | 'search'>('home');
  const [selectedCategory, setSelectedCategory] = useState<string>('home');
  const [selectedArticleSlug, setSelectedArticleSlug] = useState<string>(ARTICLES[0].slug);
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Modals
  const [isDiscountModalOpen, setIsDiscountModalOpen] = useState<boolean>(false);
  const [isOfferModalOpen, setIsOfferModalOpen] = useState<boolean>(false);
  const [hasShownOfferModal, setHasShownOfferModal] = useState<boolean>(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState<boolean>(false);
  const [selectedDrug, setSelectedDrug] = useState<Drug | null>(null);
  const [isChatBotOpen, setIsChatBotOpen] = useState<boolean>(false);

  // Toast
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((current) => (current === msg ? null : current));
    }, 4000);
  };

  const handleNavigate = (view: string, param?: string) => {
    window.scrollTo({ top: 0, behavior: 'smooth' });

    if (view === 'home') {
      setCurrentView('home');
      setSelectedCategory('home');
      setSearchQuery('');
    } else if (view === 'category' && param) {
      setCurrentView('category');
      setSelectedCategory(param);
    } else if (view === 'article' && param) {
      setCurrentView('article');
      setSelectedArticleSlug(param);

      // Trigger instant product offer modal 1.2 seconds after viewing an article (once per session)
      if (!hasShownOfferModal) {
        setTimeout(() => {
          setIsOfferModalOpen(true);
          setHasShownOfferModal(true);
        }, 1200);
      }
    } else if (view === 'search') {
      setCurrentView('search');
    }
  };

  const activeArticle = ARTICLES.find((a) => a.slug === selectedArticleSlug) || ARTICLES[0];
  const activeCategoryObj = CATEGORIES.find((c) => c.slug === selectedCategory) || CATEGORIES[0];

  // Articles filtered by category
  const categoryArticles = ARTICLES.filter(
    (a) => a.categoryId === selectedCategory || selectedCategory === 'all'
  );

  // Filtered articles and drugs for global search
  const searchFilteredArticles = ARTICLES.filter((a) => {
    const q = searchQuery.toLowerCase().trim();
    return (
      a.title.toLowerCase().includes(q) ||
      a.excerpt.toLowerCase().includes(q) ||
      a.tags.some((t) => t.toLowerCase().includes(q))
    );
  });

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-800" dir="rtl">
      {/* Toast Notification */}
      <Toast message={toastMessage} onClose={() => setToastMessage(null)} />

      {/* Header */}
      <Header
        currentView={currentView}
        selectedCategory={selectedCategory}
        onNavigate={handleNavigate}
        onOpenAuth={() => setIsAuthModalOpen(true)}
        onOpenDiscount={() => setIsDiscountModalOpen(true)}
        onOpenChat={() => setIsChatBotOpen(true)}
        searchQuery={searchQuery}
        onSearchChange={(q) => {
          setSearchQuery(q);
          if (q.trim() && currentView !== 'search') {
            setCurrentView('search');
          }
        }}
      />

      {/* Main Content Areas based on SPA View */}
      <main className="flex-1">
        {/* VIEW 1: Single Article View */}
        {currentView === 'article' && (
          <ArticleView
            article={activeArticle}
            offerProducts={OFFER_PRODUCTS}
            onBack={() => handleNavigate('home')}
            onNavigateCategory={(slug) => handleNavigate('category', slug)}
            onToast={showToast}
            onOpenOfferModal={() => setIsOfferModalOpen(true)}
          />
        )}

        {/* VIEW 2: Category View */}
        {currentView === 'category' && (
          <CategoryView
            category={activeCategoryObj}
            articles={categoryArticles}
            onSelectArticle={(slug) => handleNavigate('article', slug)}
            onBackToHome={() => handleNavigate('home')}
          />
        )}

        {/* VIEW 3: Global Search View */}
        {currentView === 'search' && (
          <div className="max-w-7xl mx-auto px-4 py-8" id="search-results-view">
            <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 mb-8">
              <h2 className="text-xl font-bold text-slate-900 mb-2">
                نتایج جستجو برای: <span className="text-rose-600 font-mono">"{searchQuery}"</span>
              </h2>
              <p className="text-xs text-slate-500">
                {searchFilteredArticles.length} مقاله سلامت یافت شد
              </p>
            </div>

            {searchFilteredArticles.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {searchFilteredArticles.map((art) => (
                  <article
                    key={art.id}
                    onClick={() => handleNavigate('article', art.slug)}
                    className="group bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-xs hover:shadow-lg transition-all cursor-pointer flex flex-col justify-between"
                  >
                    <div>
                      <div className="aspect-16/10 overflow-hidden bg-slate-100">
                        <img
                          src={art.imageUrl}
                          alt={art.title}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                        />
                      </div>
                      <div className="p-5">
                        <span className="text-xs font-bold text-rose-600 mb-2 inline-block">
                          {art.category}
                        </span>
                        <h3 className="font-bold text-slate-900 text-sm leading-snug line-clamp-2 mb-2">
                          {art.title}
                        </h3>
                        <p className="text-xs text-slate-500 line-clamp-2">
                          {art.excerpt}
                        </p>
                      </div>
                    </div>
                    <div className="px-5 pb-5 pt-2 border-t border-slate-100 text-xs text-slate-400 flex justify-between">
                      <span>{art.author}</span>
                      <span className="text-rose-600 font-bold">مشاهده مقاله ←</span>
                    </div>
                  </article>
                ))}
              </div>
            ) : (
              <div className="bg-white rounded-3xl p-12 text-center border border-slate-200">
                <p className="text-slate-500 text-sm">مقاله‌ای با این مشخصات یافت نشد.</p>
                <button
                  onClick={() => handleNavigate('home')}
                  className="mt-4 inline-flex items-center gap-1.5 bg-rose-600 text-white text-xs font-bold px-4 py-2 rounded-xl cursor-pointer"
                >
                  بازگشت به صفحه اصلی
                </button>
              </div>
            )}
          </div>
        )}

        {/* VIEW 4: Home View (Complete Health-Tech Magazine & Services) */}
        {currentView === 'home' && (
          <>
            {/* 1. Hero Carousel */}
            <HeroCarousel onSelectArticle={(slug) => handleNavigate('article', slug)} />

            {/* 2. Trending Topics Bar */}
            <TrendingBar onSelectTag={(tag) => {
              setSearchQuery(tag);
              setCurrentView('search');
            }} />

            {/* 3. Editor's Pick (منتخب داروسازان و سردبیر) */}
            <EditorsPick
              articles={ARTICLES}
              onSelectArticle={(slug) => handleNavigate('article', slug)}
            />

            {/* 4. Digikala Mag Inspired Video Hub (جدیدترین ویدیوها) */}
            <VideoSection
              videos={VIDEOS}
              onNavigateCategory={(slug) => handleNavigate('category', slug)}
              onToast={showToast}
            />

            {/* 5. Doctor & Pharmacist Interviews (مصاحبه اختصاصی با متخصصان) */}
            <DoctorInterviews
              interviews={INTERVIEWS}
              onToast={showToast}
            />

            {/* 6. Drug Directory (بانک جامع اطلاعات دارویی با جستجوی صوتی) */}
            <DrugDirectory
              drugs={DRUGS}
              onSelectDrug={(drug) => setSelectedDrug(drug)}
              onToast={showToast}
            />

            {/* 7. Comparative Rankings (پربحث‌ترین و پربازدیدترین مقالات) */}
            <ComparisonSections
              articles={ARTICLES}
              onSelectArticle={(slug) => handleNavigate('article', slug)}
            />

            {/* 8. Latest Articles Feed (جدیدترین مقالات مجله مرکز دارو) */}
            <LatestArticles
              articles={ARTICLES}
              onSelectArticle={(slug) => handleNavigate('article', slug)}
            />

            {/* 9. Newsletter & Club Voucher Banner */}
            <NewsletterBanner onClaimDiscount={(phone) => {
              showToast(`شماره ${phone} با موفقیت ثبت شد. کد تخفیف SALAMAT100 برای شما فعال است.`);
            }} />
          </>
        )}
      </main>

      {/* Footer */}
      <Footer
        onNavigate={handleNavigate}
        onOpenDiscount={() => setIsDiscountModalOpen(true)}
        onOpenChat={() => setIsChatBotOpen(true)}
      />

      {/* Floating 24/7 AI Pharmacist Chat Widget */}
      <AIChatBot
        isOpen={isChatBotOpen}
        onClose={() => setIsChatBotOpen(false)}
        onToggle={() => setIsChatBotOpen((prev) => !prev)}
      />

      {/* Interactive Modals (Lead Gen Voucher, Special Product Offer, Auth, Drug Detail) */}
      <Modals
        isDiscountOpen={isDiscountModalOpen}
        onCloseDiscount={() => setIsDiscountModalOpen(false)}
        isOfferOpen={isOfferModalOpen}
        onCloseOffer={() => setIsOfferModalOpen(false)}
        offerProduct={OFFER_PRODUCTS[0]}
        isAuthOpen={isAuthModalOpen}
        onCloseAuth={() => setIsAuthModalOpen(false)}
        selectedDrug={selectedDrug}
        onCloseDrug={() => setSelectedDrug(null)}
        onToast={showToast}
      />
    </div>
  );
}
