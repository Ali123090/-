import React, { useState, useRef, useEffect } from 'react';
import { Pill, Search, ShieldAlert, Sparkles, ChevronLeft, Info, AlertTriangle, Mic, MicOff, X, Volume2 } from 'lucide-react';
import { Drug } from '../types';

interface DrugDirectoryProps {
  drugs: Drug[];
  onSelectDrug: (drug: Drug) => void;
  onToast?: (msg: string) => void;
}

export const DrugDirectory: React.FC<DrugDirectoryProps> = ({ drugs, onSelectDrug, onToast }) => {
  const [filterType, setFilterType] = useState<'all' | 'Rx' | 'OTC'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [isListening, setIsListening] = useState(false);
  const [spokenInterim, setSpokenInterim] = useState('');
  const recognitionRef = useRef<any>(null);

  // Initialize and clean up SpeechRecognition
  useEffect(() => {
    return () => {
      if (recognitionRef.current) {
        try {
          recognitionRef.current.stop();
        } catch {
          // ignore
        }
      }
    };
  }, []);

  const toggleVoiceSearch = () => {
    if (isListening) {
      if (recognitionRef.current) {
        try {
          recognitionRef.current.stop();
        } catch {
          // ignore
        }
      }
      setIsListening(false);
      return;
    }

    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      onToast?.('مرورگر شما از جستجوی صوتی مستقیم پشتیبانی نمی‌کند. لطفاً نام دارو را تایپ کنید.');
      return;
    }

    try {
      const recognition = new SpeechRecognition();
      recognition.lang = 'fa-IR';
      recognition.interimResults = true;
      recognition.continuous = false;
      recognition.maxAlternatives = 1;
      recognitionRef.current = recognition;

      recognition.onstart = () => {
        setIsListening(true);
        setSpokenInterim('');
        onToast?.('میکروفون فعال شد؛ نام دارو یا بیماری را بگویید...');
      };

      recognition.onresult = (event: any) => {
        let interimText = '';
        let finalText = '';

        for (let i = event.resultIndex; i < event.results.length; ++i) {
          if (event.results[i].isFinal) {
            finalText += event.results[i][0].transcript;
          } else {
            interimText += event.results[i][0].transcript;
          }
        }

        const recognized = finalText || interimText;
        if (interimText) {
          setSpokenInterim(interimText);
        }

        if (finalText) {
          setSearchQuery(finalText.trim());
          setSpokenInterim('');
          setIsListening(false);
          onToast?.(`جستجوی صوتی برای «${finalText.trim()}» انجام شد.`);
        }
      };

      recognition.onerror = (event: any) => {
        setIsListening(false);
        setSpokenInterim('');
        if (event.error === 'not-allowed' || event.error === 'service-not-allowed') {
          onToast?.('دسترسی به میکروفون تایید نشد. لطفاً دسترسی را در مرورگر مجاز کنید.');
        } else if (event.error === 'no-speech') {
          onToast?.('صدایی تشخیص داده نشد. لطفاً مجدداً امتحان کنید.');
        } else {
          onToast?.('خطا در دریافت صوت. لطفاً دوباره امتحان کنید.');
        }
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      recognition.start();
    } catch (err) {
      setIsListening(false);
      onToast?.('امکان اتصال به سرویس تشخیص گفتار وجود ندارد.');
    }
  };

  const handleClearSearch = () => {
    setSearchQuery('');
    setSpokenInterim('');
  };

  const filteredDrugs = drugs.filter((drug) => {
    const matchesFilter = filterType === 'all' || drug.category === filterType;
    const q = searchQuery.toLowerCase().trim();
    const matchesSearch = 
      drug.nameFa.toLowerCase().includes(q) ||
      drug.nameEn.toLowerCase().includes(q) ||
      drug.genericName.toLowerCase().includes(q) ||
      drug.indications.toLowerCase().includes(q);
    return matchesFilter && matchesSearch;
  });

  return (
    <section className="max-w-7xl mx-auto px-4 mt-12" id="drug-directory-section">
      <div className="rounded-3xl bg-gradient-to-br from-slate-900 via-slate-800 to-indigo-950 p-6 md:p-8 text-white shadow-xl">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-slate-700/60">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-indigo-500/20 border border-indigo-400/30 text-indigo-300 flex items-center justify-center">
              <Pill className="w-6 h-6 rotate-45 text-indigo-400" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl md:text-2xl font-extrabold text-white">بانک جامع اطلاعات دارویی</h2>
                <span className="bg-indigo-500/30 text-indigo-200 text-xs px-2.5 py-0.5 rounded-full border border-indigo-400/30 font-mono">
                  فارماکوپه ایران
                </span>
              </div>
              <p className="text-xs text-slate-300 mt-1">
                اطلاعات بالینی، دوز مصرفی، تداخلات دارویی و عوارض جانبی بیش از ۲۰۰۰ قلم دارو
              </p>
            </div>
          </div>

          {/* Filter Tabs */}
          <div className="flex items-center gap-1.5 bg-slate-900/80 p-1.5 rounded-2xl border border-slate-700 shrink-0">
            <button
              onClick={() => setFilterType('all')}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                filterType === 'all'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'text-slate-400 hover:text-white'
              }`}
              id="filter-drugs-all"
            >
              همه داروها ({drugs.length})
            </button>
            <button
              onClick={() => setFilterType('Rx')}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                filterType === 'Rx'
                  ? 'bg-rose-600 text-white shadow-xs'
                  : 'text-slate-400 hover:text-white'
              }`}
              id="filter-drugs-rx"
            >
              نسخه‌ای (Rx)
            </button>
            <button
              onClick={() => setFilterType('OTC')}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                filterType === 'OTC'
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'text-slate-400 hover:text-white'
              }`}
              id="filter-drugs-otc"
            >
              بدون نسخه (OTC)
            </button>
          </div>
        </div>

        {/* Live Search Input with Voice Search & Clear buttons */}
        <div className="mt-6 max-w-xl">
          <div className="relative flex items-center">
            <input
              type="text"
              placeholder={isListening ? 'در حال شنیدن... نام دارو یا بیماری را بگویید' : 'جستجوی نام دارو، بیماری یا دوز (مثال: متفورمین، زینک، کبد چرب)...'}
              value={isListening && spokenInterim ? spokenInterim : searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className={`w-full bg-slate-800/90 text-white placeholder-slate-400 text-sm rounded-2xl pl-24 pr-11 py-3.5 border transition-all ${
                isListening
                  ? 'border-rose-500 ring-4 ring-rose-500/20 bg-slate-800'
                  : 'border-slate-700 focus:outline-hidden focus:border-indigo-400 focus:ring-3 focus:ring-indigo-500/20'
              }`}
              id="drug-search-input"
            />
            {/* Search Icon */}
            <div className="absolute right-3.5 text-slate-400 pointer-events-none">
              <Search className="w-5 h-5" />
            </div>

            {/* Clear Button & Voice Search Button */}
            <div className="absolute left-2.5 flex items-center gap-1.5">
              {searchQuery && !isListening && (
                <button
                  type="button"
                  onClick={handleClearSearch}
                  className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-700/60 transition-colors cursor-pointer"
                  title="پاک کردن جستجو"
                  id="clear-drug-search-btn"
                >
                  <X className="w-4 h-4" />
                </button>
              )}

              {/* Voice Search Button */}
              <button
                type="button"
                onClick={toggleVoiceSearch}
                className={`relative flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer shadow-sm ${
                  isListening
                    ? 'bg-rose-600 text-white animate-pulse shadow-rose-900/50'
                    : 'bg-indigo-600/80 hover:bg-indigo-600 text-indigo-100 hover:text-white border border-indigo-500/40'
                }`}
                title={isListening ? 'توقف ضبط صدا' : 'جستجوی صوتی با میکروفون'}
                id="drug-voice-search-btn"
              >
                {isListening ? (
                  <>
                    <span className="relative flex h-2 w-2">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-white opacity-75"></span>
                      <span className="relative inline-flex rounded-full h-2 w-2 bg-white"></span>
                    </span>
                    <MicOff className="w-4 h-4" />
                    <span className="hidden sm:inline">شنیدن...</span>
                  </>
                ) : (
                  <>
                    <Mic className="w-4 h-4 text-indigo-200" />
                    <span className="hidden sm:inline">جستجوی صوتی</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Active Voice Search Feedback Banner */}
          {isListening && (
            <div className="mt-2.5 flex items-center justify-between bg-rose-950/70 border border-rose-500/40 rounded-xl px-3.5 py-2 text-xs text-rose-200 animate-in fade-in slide-in-from-top-1 duration-200">
              <div className="flex items-center gap-2">
                <div className="flex items-center gap-1">
                  <span className="w-1.5 h-3 bg-rose-400 rounded-full animate-bounce [animation-delay:-0.3s]"></span>
                  <span className="w-1.5 h-4 bg-rose-400 rounded-full animate-bounce [animation-delay:-0.15s]"></span>
                  <span className="w-1.5 h-2.5 bg-rose-400 rounded-full animate-bounce"></span>
                </div>
                <span>میکروفون فعال است؛ نام دارو را به فارسی بگویید...</span>
              </div>
              <button
                onClick={toggleVoiceSearch}
                className="text-[11px] font-bold text-rose-300 hover:text-white underline cursor-pointer"
              >
                توقف
              </button>
            </div>
          )}

          {/* Quick Voice Suggestions */}
          <div className="flex items-center gap-2 mt-2.5 overflow-x-auto py-1 scrollbar-none text-[11px] text-slate-400">
            <span className="shrink-0 text-slate-500">پیشنهاد سریع:</span>
            {['متفورمین', 'زینک پلاس', 'امپرازول', 'ناپروکسن', 'ویتامین دی'].map((suggest) => (
              <button
                key={suggest}
                type="button"
                onClick={() => setSearchQuery(suggest)}
                className="bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white px-2.5 py-1 rounded-lg transition-colors shrink-0 cursor-pointer border border-slate-700/60"
              >
                {suggest}
              </button>
            ))}
          </div>
        </div>

        {/* Drug Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mt-6">
          {filteredDrugs.map((drug) => {
            const isRx = drug.category === 'Rx';
            return (
              <div
                key={drug.id}
                className="bg-slate-800/80 hover:bg-slate-800 border border-slate-700 hover:border-indigo-400/50 rounded-2xl p-4 transition-all flex flex-col justify-between group shadow-sm hover:shadow-lg"
                id={`drug-card-${drug.id}`}
              >
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md font-mono ${
                      isRx 
                        ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30' 
                        : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                    }`}>
                      {isRx ? 'نیازمند نسخه (Rx)' : 'بدون نسخه (OTC)'}
                    </span>
                    <span className="text-[10px] text-slate-400">{drug.form}</span>
                  </div>

                  <h3 className="font-bold text-white text-sm group-hover:text-indigo-300 transition-colors">
                    {drug.nameFa}
                  </h3>
                  <p className="text-[11px] font-mono text-slate-400 mb-2">
                    {drug.nameEn}
                  </p>

                  <p className="text-xs text-slate-300 line-clamp-2 leading-relaxed mb-3">
                    <strong className="text-slate-400 font-normal">موارد مصرف: </strong>
                    {drug.indications}
                  </p>
                </div>

                <div className="pt-3 border-t border-slate-700/70 flex items-center justify-between">
                  <span className="text-[10px] text-slate-400">
                    دوز: <span className="text-slate-200 font-mono">{drug.strength}</span>
                  </span>

                  <button
                    onClick={() => onSelectDrug(drug)}
                    className="inline-flex items-center gap-1 text-xs font-semibold text-indigo-400 hover:text-indigo-300 cursor-pointer group-hover:translate-x-[-2px] transition-transform"
                    id={`view-drug-detail-${drug.id}`}
                  >
                    <span>اطلاعات بالینی</span>
                    <ChevronLeft className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {filteredDrugs.length === 0 && (
          <div className="text-center py-12 text-slate-400">
            <AlertTriangle className="w-8 h-8 mx-auto mb-2 text-amber-400" />
            <p className="text-sm">هیچ دارویی مطابق با عبارت جستجوی شما یافت نشد.</p>
            {searchQuery && (
              <button
                onClick={handleClearSearch}
                className="mt-3 text-xs text-indigo-400 hover:text-indigo-300 underline cursor-pointer"
              >
                پاک کردن جستجو و نمایش همه داروها
              </button>
            )}
          </div>
        )}
      </div>
    </section>
  );
};

