import React from 'react';
import { ArrowRight, Clock, MessageSquare, ShieldCheck, ArrowLeft } from 'lucide-react';
import { Article, Category } from '../types';

interface CategoryViewProps {
  category: Category;
  articles: Article[];
  onSelectArticle: (slug: string) => void;
  onBackToHome: () => void;
}

export const CategoryView: React.FC<CategoryViewProps> = ({
  category,
  articles,
  onSelectArticle,
  onBackToHome
}) => {
  return (
    <div className="max-w-7xl mx-auto px-4 py-6" id="category-archive-view">
      {/* Breadcrumbs */}
      <nav className="flex items-center gap-2 text-xs text-slate-500 mb-6 font-medium">
        <button 
          onClick={onBackToHome} 
          className="hover:text-rose-600 transition-colors flex items-center gap-1 cursor-pointer"
          id="category-breadcrumb-home"
        >
          <ArrowRight className="w-3.5 h-3.5" />
          <span>صفحه اصلی</span>
        </button>
        <span>/</span>
        <span className="text-slate-800 font-bold">{category.name}</span>
      </nav>

      {/* Category Hero Banner */}
      <div className="bg-gradient-to-r from-slate-900 to-indigo-950 text-white rounded-3xl p-6 sm:p-8 mb-8 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <span className="text-xs font-bold text-rose-400 bg-rose-500/20 px-3 py-1 rounded-full border border-rose-500/30 inline-block mb-3">
              آرشیو تخصصی مقالات
            </span>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white mb-2">
              {category.name}
            </h1>
            <p className="text-slate-300 text-xs sm:text-sm max-w-xl leading-relaxed">
              {category.description}
            </p>
          </div>

          <div className="bg-white/10 backdrop-blur-md rounded-2xl p-4 border border-white/15 text-center shrink-0">
            <span className="text-2xl sm:text-3xl font-black text-rose-400 font-mono block">
              {articles.length}
            </span>
            <span className="text-[11px] text-slate-300">مقاله تخصصی</span>
          </div>
        </div>
      </div>

      {/* Articles Grid */}
      {articles.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {articles.map((art) => (
            <article
              key={art.id}
              onClick={() => onSelectArticle(art.slug)}
              className="group bg-white rounded-3xl border border-slate-200/90 overflow-hidden shadow-xs hover:shadow-lg transition-all hover:-translate-y-1 cursor-pointer flex flex-col justify-between"
              id={`cat-article-${art.id}`}
            >
              <div>
                <div className="relative aspect-16/10 overflow-hidden bg-slate-100">
                  <img
                    src={art.imageUrl}
                    alt={art.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <span className="absolute top-3 right-3 bg-white/95 backdrop-blur-xs text-rose-600 font-bold text-[11px] px-2.5 py-1 rounded-full shadow-xs">
                    {art.category}
                  </span>
                  {art.verifiedDoctor && (
                    <span className="absolute bottom-3 left-3 bg-emerald-600/90 backdrop-blur-xs text-white text-[10px] font-medium px-2 py-0.5 rounded-full flex items-center gap-1 shadow-xs">
                      <ShieldCheck className="w-3 h-3" />
                      تأییدیه بالینی
                    </span>
                  )}
                </div>

                <div className="p-5">
                  <div className="flex items-center gap-3 text-[11px] text-slate-400 mb-2">
                    <span className="flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5" />
                      {art.readTime}
                    </span>
                    <span>•</span>
                    <span>{art.date}</span>
                  </div>

                  <h3 className="font-bold text-slate-900 text-sm sm:text-base leading-snug group-hover:text-rose-600 transition-colors line-clamp-2 mb-2">
                    {art.title}
                  </h3>

                  <p className="text-xs text-slate-500 line-clamp-2 leading-relaxed">
                    {art.excerpt}
                  </p>
                </div>
              </div>

              <div className="px-5 pb-5 pt-3 border-t border-slate-100 flex items-center justify-between">
                <span className="text-[11px] text-slate-600 font-medium">{art.author}</span>
                <span className="text-rose-600 text-xs font-bold flex items-center gap-1">
                  <span>مشاهده</span>
                  <ArrowLeft className="w-3.5 h-3.5" />
                </span>
              </div>
            </article>
          ))}
        </div>
      ) : (
        <div className="bg-white rounded-3xl p-12 text-center border border-slate-200">
          <p className="text-slate-500 text-sm">در این دسته‌بندی در حال حاضر مقاله‌ای ثبت نشده است.</p>
          <button
            onClick={onBackToHome}
            className="mt-4 inline-flex items-center gap-1.5 bg-rose-600 text-white text-xs font-bold px-4 py-2 rounded-xl cursor-pointer"
          >
            <ArrowRight className="w-4 h-4" />
            <span>بازگشت به صفحه اصلی</span>
          </button>
        </div>
      )}
    </div>
  );
};
