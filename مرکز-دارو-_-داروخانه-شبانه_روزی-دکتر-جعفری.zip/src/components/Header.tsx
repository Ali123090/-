import React, { useState } from 'react';
import { 
  PhoneCall, 
  MapPin, 
  Bot, 
  User, 
  Search, 
  Gift, 
  Home, 
  Sparkles, 
  Dumbbell, 
  ShieldAlert, 
  Pill, 
  Video, 
  Baby, 
  HeartHandshake,
  Clock,
  CheckCircle2,
  X
} from 'lucide-react';
import { CATEGORIES } from '../data';

interface HeaderProps {
  currentView: string;
  selectedCategory: string;
  onNavigate: (view: string, param?: string) => void;
  onOpenAuth: () => void;
  onOpenDiscount: () => void;
  onOpenChat: () => void;
  searchQuery: string;
  onSearchChange: (q: string) => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentView,
  selectedCategory,
  onNavigate,
  onOpenAuth,
  onOpenDiscount,
  onOpenChat,
  searchQuery,
  onSearchChange
}) => {
  const [localSearch, setLocalSearch] = useState(searchQuery);

  const getCategoryIcon = (iconName: string) => {
    switch (iconName) {
      case 'Home': return <Home className="w-4 h-4" />;
      case 'Sparkles': return <Sparkles className="w-4 h-4" />;
      case 'Dumbbell': return <Dumbbell className="w-4 h-4" />;
      case 'ShieldAlert': return <ShieldAlert className="w-4 h-4" />;
      case 'Pill': return <Pill className="w-4 h-4" />;
      case 'Video': return <Video className="w-4 h-4" />;
      case 'Baby': return <Baby className="w-4 h-4" />;
      case 'HeartHandshake': return <HeartHandshake className="w-4 h-4" />;
      default: return <Pill className="w-4 h-4" />;
    }
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSearchChange(localSearch);
    if (localSearch.trim()) {
      onNavigate('search', localSearch);
    }
  };

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200 shadow-xs">
      {/* Top Bar (24/7 hotline and emergency contacts) */}
      <div className="bg-slate-900 text-slate-300 text-xs py-2 px-4 border-b border-slate-800">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-4">
            <span className="inline-flex items-center gap-1.5 text-emerald-400 font-semibold">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
              </span>
              داروخانه شبانه‌روزی فعال (۲۴ ساعته)
            </span>
            <span className="hidden md:inline-flex items-center gap-1 text-slate-400">
              <Clock className="w-3.5 h-3.5 text-slate-500" />
              پاسخگویی داروساز کشیک بدون تعطیلی
            </span>
            <span className="hidden lg:inline-flex items-center gap-1 text-slate-400">
              <MapPin className="w-3.5 h-3.5 text-slate-500" />
              تهران، خ ولیعصر، نرسیده به میدان ونک، پلاک ۲۴
            </span>
          </div>

          <div className="flex items-center gap-3">
            <a 
              href="tel:02188884500" 
              className="inline-flex items-center gap-1 text-slate-200 hover:text-emerald-400 transition-colors font-mono font-medium"
              id="header-phone-link"
            >
              <PhoneCall className="w-3.5 h-3.5 text-emerald-400" />
              <span>۰۲۱-۸۸۸۸۴۵۰۰</span>
            </a>
            <span className="text-slate-700">|</span>
            <button
              onClick={onOpenChat}
              className="inline-flex items-center gap-1 text-rose-400 hover:text-rose-300 transition-colors cursor-pointer"
              id="header-pharmacist-chat-btn"
            >
              <Bot className="w-3.5 h-3.5" />
              <span>مشاوره داروساز آنلاین</span>
            </button>
            <span className="text-slate-700">|</span>
            <button
              onClick={onOpenAuth}
              className="inline-flex items-center gap-1 text-slate-300 hover:text-white transition-colors cursor-pointer"
              id="header-auth-btn"
            >
              <User className="w-3.5 h-3.5" />
              <span>ورود / عضویت</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Header */}
      <div className="max-w-7xl mx-auto px-4 py-3.5 flex flex-col md:flex-row items-center justify-between gap-4">
        {/* Brand Logo */}
        <div 
          onClick={() => onNavigate('home')} 
          className="flex items-center gap-3 cursor-pointer select-none group"
          id="header-brand-logo"
        >
          <div className="w-11 h-11 rounded-xl bg-gradient-to-tr from-rose-600 to-rose-500 flex items-center justify-center text-white shadow-md shadow-rose-200 group-hover:scale-105 transition-transform">
            <div className="relative">
              <Pill className="w-6 h-6 rotate-45" />
              <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-emerald-400 rounded-full border-2 border-white"></span>
            </div>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-extrabold text-2xl tracking-tight text-slate-900 group-hover:text-rose-600 transition-colors">
                مرکز دارو
              </span>
              <span className="text-[10px] bg-rose-100 text-rose-700 font-bold px-1.5 py-0.5 rounded-sm">
                ۲۴ ساعته
              </span>
            </div>
            <p className="text-[11px] text-slate-500 font-medium">
              داروخانه شبانه‌روزی و مجله پزشکی دکتر جعفری
            </p>
          </div>
        </div>

        {/* Live Search Bar */}
        <form 
          onSubmit={handleSearchSubmit} 
          className="relative w-full md:max-w-lg"
          id="header-search-form"
        >
          <div className="relative flex items-center">
            <input
              type="text"
              placeholder="جستجو در مقالات سلامت، داروها، مکمل‌ها، ویدیوها..."
              value={localSearch}
              onChange={(e) => {
                setLocalSearch(e.target.value);
                onSearchChange(e.target.value);
              }}
              className="w-full bg-slate-100 text-slate-800 placeholder-slate-400 text-sm rounded-full pl-10 pr-11 py-2.5 border border-slate-200 focus:outline-hidden focus:border-rose-500 focus:bg-white focus:ring-3 focus:ring-rose-100 transition-all"
              id="header-search-input"
            />
            <div className="absolute right-3.5 text-slate-400">
              <Search className="w-4 h-4" />
            </div>
            {localSearch && (
              <button
                type="button"
                onClick={() => {
                  setLocalSearch('');
                  onSearchChange('');
                }}
                className="absolute left-3 text-slate-400 hover:text-slate-600 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>
        </form>

        {/* Quick Actions */}
        <div className="flex items-center gap-2.5 shrink-0">
          <button
            onClick={onOpenDiscount}
            className="flex items-center gap-2 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-white text-xs font-semibold px-3.5 py-2.5 rounded-full shadow-sm hover:shadow-md transition-all cursor-pointer"
            id="header-discount-code-btn"
          >
            <Gift className="w-4 h-4 animate-bounce" />
            <span className="hidden sm:inline">کد تخفیف ۱۰۰ تومانی</span>
            <span className="sm:hidden">تخفیف</span>
          </button>

          <button
            onClick={onOpenChat}
            className="flex items-center gap-2 bg-rose-600 hover:bg-rose-700 text-white text-xs font-semibold px-4 py-2.5 rounded-full shadow-sm hover:shadow-md transition-all cursor-pointer"
            id="header-ai-pharmacist-btn"
          >
            <Bot className="w-4 h-4" />
            <span>مشاوره هوشمند داروساز</span>
          </button>
        </div>
      </div>

      {/* Category Navigation Bar */}
      <nav className="border-t border-slate-100 bg-white">
        <div className="max-w-7xl mx-auto px-4">
          <ul className="flex items-center gap-1 overflow-x-auto py-1 scrollbar-none text-xs font-medium">
            {CATEGORIES.map((cat) => {
              const isActive = (currentView === 'home' && cat.id === 'all') || 
                               (currentView === 'category' && selectedCategory === cat.slug);
              return (
                <li key={cat.id} className="shrink-0">
                  <button
                    onClick={() => {
                      if (cat.id === 'all') {
                        onNavigate('home');
                      } else {
                        onNavigate('category', cat.slug);
                      }
                    }}
                    className={`flex items-center gap-1.5 px-3 py-2 rounded-lg transition-all cursor-pointer ${
                      isActive
                        ? 'bg-rose-50 text-rose-700 font-bold border-b-2 border-rose-600'
                        : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                    }`}
                    id={`nav-category-${cat.slug}`}
                  >
                    <span className={isActive ? 'text-rose-600' : 'text-slate-400'}>
                      {getCategoryIcon(cat.iconName)}
                    </span>
                    <span>{cat.name}</span>
                  </button>
                </li>
              );
            })}
          </ul>
        </div>
      </nav>
    </header>
  );
};
