import React from 'react';
import { MessageSquare, TrendingUp, Eye, ArrowLeft, Flame } from 'lucide-react';
import { Article } from '../types';

interface ComparisonSectionsProps {
  articles: Article[];
  onSelectArticle: (slug: string) => void;
}

export const ComparisonSections: React.FC<ComparisonSectionsProps> = ({
  articles,
  onSelectArticle
}) => {
  // Sort by comments count
  const mostDiscussed = [...articles].sort((a, b) => b.commentsCount - a.commentsCount).slice(0, 3);
  // Sort by views
  const mostVisited = [...articles].sort((a, b) => b.views - a.views).slice(0, 3);

  const persianNumbers = ['۰۱', '۰۲', '۰۳'];

  return (
    <section className="max-w-7xl mx-auto px-4 mt-12" id="comparison-rankings-section">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Column 1: Most Discussed */}
        <div className="bg-white rounded-3xl p-6 border border-slate-200/90 shadow-xs">
          <div className="flex items-center gap-3 pb-4 mb-4 border-b border-slate-100">
            <div className="w-10 h-10 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center">
              <MessageSquare className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-slate-900 text-base">پربحث‌ترین مقالات سلامت</h3>
              <p className="text-xs text-slate-500">گفتگوها و پرسش‌وپاسخ‌های بیماران با داروسازان</p>
            </div>
          </div>

          <div className="space-y-4">
            {mostDiscussed.map((art) => (
              <div
                key={art.id}
                onClick={() => onSelectArticle(art.slug)}
                className="group flex items-start gap-4 p-3 rounded-2xl hover:bg-slate-50 transition-all cursor-pointer border border-transparent hover:border-slate-200/80"
                id={`most-discussed-${art.id}`}
              >
                <img
                  src={art.imageUrl}
                  alt={art.title}
                  className="w-20 h-16 rounded-xl object-cover shrink-0 shadow-xs"
                />
                <div className="flex-1 min-w-0">
                  <span className="text-[10px] font-bold text-rose-600 bg-rose-50 px-2 py-0.5 rounded-full inline-block mb-1">
                    {art.category}
                  </span>
                  <h4 className="font-bold text-slate-800 text-xs leading-snug group-hover:text-rose-600 transition-colors line-clamp-2">
                    {art.title}
                  </h4>
                  <div className="flex items-center gap-2 mt-1.5 text-[11px] text-slate-400">
                    <span className="flex items-center gap-1 text-slate-500 font-medium">
                      <MessageSquare className="w-3 h-3 text-rose-500" />
                      {art.commentsCount} نظر ثبت شده
                    </span>
                    <span>•</span>
                    <span>{art.author}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Column 2: Most Visited */}
        <div className="bg-white rounded-3xl p-6 border border-slate-200/90 shadow-xs">
          <div className="flex items-center gap-3 pb-4 mb-4 border-b border-slate-100">
            <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center">
              <TrendingUp className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-slate-900 text-base">پربازدیدترین مقالات ماه</h3>
              <p className="text-xs text-slate-500">محبوب‌ترین راهنماهای دارویی به انتخاب کاربران</p>
            </div>
          </div>

          <div className="space-y-4">
            {mostVisited.map((art, idx) => (
              <div
                key={art.id}
                onClick={() => onSelectArticle(art.slug)}
                className="group flex items-center gap-4 p-3 rounded-2xl hover:bg-slate-50 transition-all cursor-pointer border border-transparent hover:border-slate-200/80"
                id={`most-visited-${art.id}`}
              >
                <div className="text-2xl font-extrabold text-slate-300 group-hover:text-amber-500 font-mono transition-colors shrink-0 w-8 text-center">
                  {persianNumbers[idx]}
                </div>
                <div className="flex-1 min-w-0">
                  <h4 className="font-bold text-slate-800 text-xs md:text-sm leading-snug group-hover:text-amber-600 transition-colors line-clamp-2">
                    {art.title}
                  </h4>
                  <div className="flex items-center gap-3 mt-1.5 text-[11px] text-slate-400">
                    <span className="flex items-center gap-1 text-slate-500">
                      <Eye className="w-3 h-3 text-amber-500" />
                      {art.views.toLocaleString('fa-IR')} بازدید
                    </span>
                    <span>•</span>
                    <span className="text-rose-600 font-medium">{art.category}</span>
                  </div>
                </div>
                <ArrowLeft className="w-4 h-4 text-slate-300 group-hover:text-amber-500 group-hover:-translate-x-1 transition-all shrink-0" />
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
