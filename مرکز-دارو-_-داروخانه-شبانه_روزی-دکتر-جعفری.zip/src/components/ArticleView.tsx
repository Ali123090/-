import React, { useState } from 'react';
import { 
  ArrowRight, 
  Clock, 
  Share2, 
  Printer, 
  ShieldAlert, 
  ShieldCheck, 
  UploadCloud, 
  ShoppingBag, 
  Star, 
  Check, 
  Plus,
  Play
} from 'lucide-react';
import { Article, OfferProduct } from '../types';

interface ArticleViewProps {
  article: Article;
  offerProducts: OfferProduct[];
  onBack: () => void;
  onNavigateCategory: (slug: string) => void;
  onToast: (msg: string) => void;
  onOpenOfferModal: () => void;
}

export const ArticleView: React.FC<ArticleViewProps> = ({
  article,
  offerProducts,
  onBack,
  onNavigateCategory,
  onToast,
  onOpenOfferModal
}) => {
  const [cartState, setCartState] = useState<Record<string, boolean>>({});
  const [prescriptionUploaded, setPrescriptionUploaded] = useState(false);

  const handleAddToCart = (product: OfferProduct) => {
    setCartState(prev => ({ ...prev, [product.id]: true }));
    onToast(`محصول "${product.name}" با تخفیف به سبد خرید افزوده شد.`);
  };

  const handleShare = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(window.location.href);
      onToast('لینک این مقاله پزشکی در حافظه کپی شد.');
    } else {
      onToast('لینک کپی شد.');
    }
  };

  const handlePrint = () => {
    window.print();
  };

  const handlePrescriptionUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setPrescriptionUploaded(true);
      onToast('نسخه شما با موفقیت آپلود شد. داروساز کشیک در حال بررسی است.');
    }
  };

  return (
    <article className="max-w-7xl mx-auto px-4 py-6" id="single-article-view">
      {/* Breadcrumbs Navigation */}
      <nav className="flex items-center gap-2 text-xs text-slate-500 mb-6 flex-wrap">
        <button 
          onClick={onBack} 
          className="hover:text-rose-600 transition-colors flex items-center gap-1 cursor-pointer font-medium"
          id="article-breadcrumb-home"
        >
          <ArrowRight className="w-3.5 h-3.5" />
          <span>صفحه اصلی</span>
        </button>
        <span>/</span>
        <button
          onClick={() => onNavigateCategory(article.categoryId)}
          className="hover:text-rose-600 transition-colors cursor-pointer font-medium"
          id="article-breadcrumb-category"
        >
          {article.category}
        </button>
        <span>/</span>
        <span className="text-slate-800 font-bold truncate max-w-xs sm:max-w-md">
          {article.title}
        </span>
      </nav>

      {/* Main Grid: Content (8 cols) + Sticky Sidebar (4 cols) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Article Main Content (8 cols) */}
        <div className="lg:col-span-8 bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/90 shadow-sm">
          {/* Header & Meta */}
          <div className="border-b border-slate-100 pb-6 mb-6">
            <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
              <span className="bg-rose-50 text-rose-700 text-xs font-bold px-3 py-1 rounded-full border border-rose-100">
                {article.category}
              </span>

              <div className="flex items-center gap-2">
                <button
                  onClick={handleShare}
                  className="p-2 text-slate-500 hover:text-rose-600 hover:bg-rose-50 rounded-xl transition-all cursor-pointer"
                  title="اشتراک‌گذاری"
                  id="article-share-btn"
                >
                  <Share2 className="w-4 h-4" />
                </button>
                <button
                  onClick={handlePrint}
                  className="p-2 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-xl transition-all cursor-pointer"
                  title="چاپ مقاله"
                  id="article-print-btn"
                >
                  <Printer className="w-4 h-4" />
                </button>
              </div>
            </div>

            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 leading-tight mb-4">
              {article.title}
            </h1>

            {/* Author details */}
            <div className="flex flex-wrap items-center justify-between gap-4 pt-2">
              <div className="flex items-center gap-3">
                <img
                  src={article.authorAvatar}
                  alt={article.author}
                  className="w-11 h-11 rounded-2xl object-cover border-2 border-rose-100 shadow-xs"
                />
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="font-bold text-slate-900 text-sm">{article.author}</span>
                    {article.verifiedDoctor && (
                      <span className="text-emerald-600" title="داروساز دارای تاییدیه نظام پزشکی">
                        <ShieldCheck className="w-4 h-4" />
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-slate-400">{article.authorRole}</p>
                </div>
              </div>

              <div className="flex items-center gap-3 text-xs text-slate-400 font-mono">
                <span>{article.date}</span>
                <span>•</span>
                <span className="flex items-center gap-1 text-slate-600 font-sans">
                  <Clock className="w-3.5 h-3.5 text-rose-500" />
                  {article.readTime}
                </span>
              </div>
            </div>
          </div>

          {/* Featured Image */}
          <div className="relative aspect-16/9 rounded-2xl overflow-hidden mb-8 bg-slate-100 shadow-xs">
            <img
              src={article.imageUrl}
              alt={article.title}
              className="w-full h-full object-cover"
            />
          </div>

          {/* Medical Disclaimer Banner */}
          <div className="bg-amber-50/80 border-r-4 border-r-amber-500 border border-amber-200/80 rounded-2xl p-4 mb-8 text-xs text-amber-900 flex items-start gap-3">
            <ShieldAlert className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
            <div className="leading-relaxed">
              <strong className="font-bold block mb-1">هشدار سلب مسئولیت پزشکی و داروشناسی:</strong>
              اطلاعات منتشر شده در این مقاله صرفاً جنبه آگاهی‌بخشی و آموزشی دارد و جایگزین تشخیص، تجویز یا مشاوره مستقیم با پزشک متخصص یا داروساز نیست. هرگز مصرف هیچ دارویی را بدون مشورت قبلی با پزشک آغاز، متوقف یا تغییر دوز ندهید.
            </div>
          </div>

          {/* Formatted Article Body */}
          <div className="prose prose-slate max-w-none text-slate-700 leading-loose text-sm sm:text-base space-y-5">
            {article.content.split('\n\n').map((paragraph, index) => {
              const trimmed = paragraph.trim();
              if (trimmed.startsWith('### ')) {
                return (
                  <h3 key={index} className="text-lg sm:text-xl font-bold text-slate-900 pt-4 pb-1 border-r-4 border-r-rose-600 pr-3">
                    {trimmed.replace('### ', '')}
                  </h3>
                );
              }
              if (trimmed.startsWith('---')) {
                return <hr key={index} className="border-slate-200 my-6" />;
              }
              if (trimmed.startsWith('- ')) {
                const items = trimmed.split('\n');
                return (
                  <ul key={index} className="list-disc list-inside space-y-2 pr-2 text-slate-600 text-sm">
                    {items.map((item, i) => (
                      <li key={i}>{item.replace('- ', '')}</li>
                    ))}
                  </ul>
                );
              }
              return (
                <p key={index} className="text-slate-600 leading-relaxed text-sm sm:text-base">
                  {trimmed}
                </p>
              );
            })}
          </div>

          {/* Tags */}
          <div className="mt-10 pt-6 border-t border-slate-100 flex flex-wrap items-center gap-2">
            <span className="text-xs font-bold text-slate-500">برچسب‌ها:</span>
            {article.tags.map((tag) => (
              <span
                key={tag}
                className="text-xs bg-slate-100 text-slate-600 px-3 py-1 rounded-full hover:bg-slate-200 transition-colors"
              >
                #{tag}
              </span>
            ))}
          </div>
        </div>

        {/* Sticky Sidebar (4 cols): Products & Prescription Upload */}
        <aside className="lg:col-span-4 space-y-6 lg:sticky lg:top-36" id="article-sidebar">
          {/* Prescription Upload Card */}
          <div className="bg-gradient-to-br from-indigo-900 to-slate-900 text-white rounded-3xl p-5 shadow-md">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-9 h-9 rounded-xl bg-indigo-600 text-white flex items-center justify-center">
                <UploadCloud className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-sm">ارسال آنلاین نسخه پزشک</h3>
                <p className="text-[11px] text-indigo-200">تحویل فوری با پیک در کمتر از ۲ ساعت</p>
              </div>
            </div>

            <p className="text-xs text-slate-300 mb-4 leading-relaxed">
              تصویر نسخه یا کد پیگیری تامین اجتماعی / بیمه سلامت خود را ارسال کنید تا داروساز اقلام را بررسی و آماده کند.
            </p>

            {prescriptionUploaded ? (
              <div className="bg-emerald-500/20 border border-emerald-400/40 rounded-xl p-3 text-center text-xs text-emerald-300 font-medium">
                نسخه ارسال شد! کارشناسان به زودی تماس می‌گیرند.
              </div>
            ) : (
              <label className="flex items-center justify-center gap-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold py-2.5 px-4 rounded-xl cursor-pointer transition-all shadow-md">
                <UploadCloud className="w-4 h-4" />
                <span>بارگذاری عکس نسخه / دفترچه</span>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handlePrescriptionUpload}
                  className="hidden"
                />
              </label>
            )}
          </div>

          {/* Recommended Discounted Products */}
          <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-xs">
            <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <ShoppingBag className="w-4 h-4 text-rose-600" />
                <h3 className="font-bold text-slate-900 text-sm">مکمل‌های توصیه شده این مقاله</h3>
              </div>
              <span className="text-[10px] font-bold text-rose-600 bg-rose-50 px-2 py-0.5 rounded-full">
                تخفیف ویژه
              </span>
            </div>

            <div className="space-y-4">
              {offerProducts.map((prod) => {
                const isAdded = cartState[prod.id];
                return (
                  <div
                    key={prod.id}
                    className="flex items-center gap-3 p-2.5 rounded-2xl border border-slate-100 hover:border-slate-200 transition-all bg-slate-50/50"
                  >
                    <img
                      src={prod.image}
                      alt={prod.name}
                      className="w-16 h-16 rounded-xl object-cover bg-white shrink-0 border border-slate-200/80"
                    />

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-1 text-[10px] text-amber-500 mb-0.5">
                        <Star className="w-3 h-3 fill-amber-400" />
                        <span className="font-mono">{prod.rating}</span>
                      </div>
                      <h4 className="font-bold text-slate-800 text-xs truncate">
                        {prod.name}
                      </h4>
                      <p className="text-[10px] text-slate-400">{prod.brand}</p>

                      <div className="flex items-center gap-2 mt-1">
                        <span className="text-xs font-bold text-rose-600 font-mono">
                          {prod.discountPrice.toLocaleString('fa-IR')} تومان
                        </span>
                        <span className="text-[10px] text-slate-400 line-through font-mono">
                          {prod.originalPrice.toLocaleString('fa-IR')}
                        </span>
                      </div>
                    </div>

                    <button
                      onClick={() => handleAddToCart(prod)}
                      className={`p-2 rounded-xl transition-all cursor-pointer shrink-0 ${
                        isAdded 
                          ? 'bg-emerald-600 text-white' 
                          : 'bg-rose-600 hover:bg-rose-700 text-white'
                      }`}
                      title={isAdded ? 'افزوده شد' : 'افزودن به سبد'}
                    >
                      {isAdded ? <Check className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
                    </button>
                  </div>
                );
              })}
            </div>

            <button
              onClick={onOpenOfferModal}
              className="w-full mt-4 bg-amber-500 hover:bg-amber-600 text-white text-xs font-bold py-2.5 rounded-xl transition-all flex items-center justify-center gap-1.5 shadow-xs cursor-pointer"
            >
              <span>مشاهده پک طلایی با ۴۰٪ تخفیف</span>
            </button>
          </div>
        </aside>
      </div>
    </article>
  );
};
