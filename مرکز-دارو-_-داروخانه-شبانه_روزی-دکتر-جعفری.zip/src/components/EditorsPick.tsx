import React from 'react';
import { Sparkles, Clock, MessageSquare, ShieldCheck, ArrowLeft } from 'lucide-react';
import { Article } from '../types';

interface EditorsPickProps {
  articles: Article[];
  onSelectArticle: (slug: string) => void;
}

export const EditorsPick: React.FC<EditorsPickProps> = ({ articles, onSelectArticle }) => {
  const topPicks = articles.slice(0, 3);

  return (
    <section className="max-w-7xl mx-auto px-4 mt-8" id="editors-pick-section">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-amber-50 text-amber-600 flex items-center justify-center">
            <Sparkles className="w-4 h-4" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-slate-900">منتخب داروسازان و سردبیر</h2>
            <p className="text-xs text-slate-500">پژوهش‌های کلینیکی با بیشترین ارجاع و بررسی تخصصی</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        {topPicks.map((art) => (
          <article
            key={art.id}
            onClick={() => onSelectArticle(art.slug)}
            className="group bg-white rounded-2xl border border-slate-200/90 overflow-hidden shadow-xs hover:shadow-md transition-all hover:-translate-y-1 cursor-pointer flex flex-col justify-between"
            id={`editors-pick-${art.id}`}
          >
            <div>
              <div className="relative aspect-16/10 overflow-hidden bg-slate-100">
                <img
                  src={art.imageUrl}
                  alt={art.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <span className="absolute top-3 right-3 bg-white/95 backdrop-blur-xs text-rose-600 font-bold text-[11px] px-2.5 py-1 rounded-full shadow-xs">
                  {art.category}
                </span>
                {art.verifiedDoctor && (
                  <span className="absolute bottom-3 left-3 bg-emerald-600/90 backdrop-blur-xs text-white text-[10px] font-medium px-2 py-0.5 rounded-full flex items-center gap-1 shadow-xs">
                    <ShieldCheck className="w-3 h-3" />
                    تأییدیه داروساز
                  </span>
                )}
              </div>

              <div className="p-4">
                <div className="flex items-center gap-3 text-[11px] text-slate-400 mb-2">
                  <span className="flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    {art.readTime}
                  </span>
                  <span>•</span>
                  <span className="flex items-center gap-1">
                    <MessageSquare className="w-3 h-3" />
                    {art.commentsCount} دیدگاه
                  </span>
                </div>

                <h3 className="font-bold text-slate-800 text-sm leading-snug group-hover:text-rose-600 transition-colors line-clamp-2 mb-2">
                  {art.title}
                </h3>

                <p className="text-xs text-slate-500 line-clamp-2 leading-relaxed">
                  {art.excerpt}
                </p>
              </div>
            </div>

            <div className="px-4 pb-4 pt-2 border-t border-slate-100 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <img
                  src={art.authorAvatar}
                  alt={art.author}
                  className="w-6 h-6 rounded-full object-cover border border-slate-200"
                />
                <span className="text-[11px] text-slate-600 font-medium">{art.author}</span>
              </div>

              <span className="text-rose-600 text-xs font-semibold flex items-center gap-0.5 group-hover:gap-1.5 transition-all">
                <span>مطالعه</span>
                <ArrowLeft className="w-3.5 h-3.5" />
              </span>
            </div>
          </article>
        ))}
      </div>
    </section>
  );
};
