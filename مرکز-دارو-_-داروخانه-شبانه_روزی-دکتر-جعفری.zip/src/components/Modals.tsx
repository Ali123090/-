import React, { useState, useEffect } from 'react';
import { 
  X, 
  Gift, 
  Clock, 
  Check, 
  Copy, 
  ShieldAlert, 
  Star, 
  ShoppingBag, 
  User, 
  Phone, 
  Lock, 
  Pill,
  CheckCircle2,
  AlertTriangle,
  ArrowLeft
} from 'lucide-react';
import { Drug, OfferProduct } from '../types';

interface ModalsProps {
  // Lead Voucher Modal
  isDiscountOpen: boolean;
  onCloseDiscount: () => void;

  // Special Offer Modal
  isOfferOpen: boolean;
  onCloseOffer: () => void;
  offerProduct?: OfferProduct;

  // Auth Modal
  isAuthOpen: boolean;
  onCloseAuth: () => void;

  // Drug Detail Modal
  selectedDrug: Drug | null;
  onCloseDrug: () => void;

  onToast: (msg: string) => void;
}

export const Modals: React.FC<ModalsProps> = ({
  isDiscountOpen,
  onCloseDiscount,
  isOfferOpen,
  onCloseOffer,
  offerProduct,
  isAuthOpen,
  onCloseAuth,
  selectedDrug,
  onCloseDrug,
  onToast
}) => {
  // Discount Voucher Form State
  const [discountName, setDiscountName] = useState('');
  const [discountPhone, setDiscountPhone] = useState('');
  const [voucherClaimed, setVoucherClaimed] = useState(false);
  const [copiedVoucher, setCopiedVoucher] = useState(false);

  // Live 15-minute countdown for Special Offer
  const [timeLeft, setTimeLeft] = useState(14 * 60 + 59);

  useEffect(() => {
    if (!isOfferOpen) return;
    const timer = setInterval(() => {
      setTimeLeft((prev) => (prev > 0 ? prev - 1 : 0));
    }, 1000);
    return () => clearInterval(timer);
  }, [isOfferOpen]);

  const formatCountdown = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  // Auth State
  const [authTab, setAuthTab] = useState<'login' | 'register'>('login');
  const [authPhone, setAuthPhone] = useState('');
  const [authName, setAuthName] = useState('');

  const handleClaimVoucher = (e: React.FormEvent) => {
    e.preventDefault();
    if (!discountPhone.trim()) return;
    setVoucherClaimed(true);
    onToast('کد تخفیف اختصاصی شما با موفقیت صادر شد!');
  };

  const copyVoucherCode = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText('SALAMAT100');
    }
    setCopiedVoucher(true);
    onToast('کد تخفیف SALAMAT100 کپی شد.');
    setTimeout(() => setCopiedVoucher(false), 3000);
  };

  const handleAuthSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!authPhone.trim()) return;
    onToast(authTab === 'login' ? 'ورود موفقیت‌آمیز بود. خوش آمدید!' : 'ثبت‌نام با موفقیت انجام شد!');
    onCloseAuth();
  };

  return (
    <>
      {/* 1. Lead Voucher Modal */}
      {isDiscountOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="relative w-full max-w-md bg-white rounded-3xl p-6 shadow-2xl border border-slate-100 animate-in fade-in zoom-in duration-200">
            <button
              onClick={onCloseDiscount}
              className="absolute top-4 left-4 p-2 text-slate-400 hover:text-slate-700 rounded-full hover:bg-slate-100 transition-colors cursor-pointer"
              id="close-discount-modal"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="text-center mb-6">
              <div className="w-14 h-14 bg-amber-100 text-amber-600 rounded-2xl flex items-center justify-center mx-auto mb-3 shadow-inner">
                <Gift className="w-7 h-7" />
              </div>
              <h3 className="text-lg font-black text-slate-900">۱۰۰,۰۰۰ تومان هدیه نقدی</h3>
              <p className="text-xs text-slate-500 mt-1">ویژه اولین خرید مکمل‌های دارویی و بهداشتی از داروخانه</p>
            </div>

            {voucherClaimed ? (
              <div className="text-center space-y-4">
                <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-4">
                  <CheckCircle2 className="w-8 h-8 text-emerald-500 mx-auto mb-2" />
                  <p className="text-xs text-slate-700 font-medium">کد تخفیف ۱۰۰ هزار تومانی شما آماده استفاده است:</p>
                  <div className="mt-3 flex items-center justify-center gap-2 bg-white border border-emerald-300 rounded-xl p-2.5">
                    <span className="font-mono font-black text-emerald-700 tracking-wider text-base">
                      SALAMAT100
                    </span>
                    <button
                      onClick={copyVoucherCode}
                      className="text-xs bg-emerald-600 hover:bg-emerald-700 text-white px-3 py-1 rounded-lg flex items-center gap-1 cursor-pointer transition-colors"
                      id="copy-voucher-code-btn"
                    >
                      {copiedVoucher ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{copiedVoucher ? 'کپی شد' : 'کپی'}</span>
                    </button>
                  </div>
                </div>
                <button
                  onClick={onCloseDiscount}
                  className="w-full bg-slate-900 text-white text-xs font-bold py-3 rounded-xl hover:bg-slate-800 transition-colors cursor-pointer"
                >
                  بستن و ادامه مطالعه
                </button>
              </div>
            ) : (
              <form onSubmit={handleClaimVoucher} className="space-y-3.5">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">نام و نام خانوادگی (اختیاری)</label>
                  <input
                    type="text"
                    value={discountName}
                    onChange={(e) => setDiscountName(e.target.value)}
                    placeholder="مثال: علی محمدی"
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-xs text-slate-800 focus:bg-white focus:outline-hidden focus:border-rose-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">شماره همراه <span className="text-rose-600">*</span></label>
                  <input
                    type="tel"
                    required
                    dir="ltr"
                    value={discountPhone}
                    onChange={(e) => setDiscountPhone(e.target.value)}
                    placeholder="۰۹۱۲۳۴۵۶۷۸۹"
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-xs text-slate-800 text-left focus:bg-white focus:outline-hidden focus:border-rose-500"
                    id="modal-discount-phone-input"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold py-3 rounded-xl shadow-md transition-all cursor-pointer flex items-center justify-center gap-1.5 mt-2"
                  id="modal-claim-voucher-btn"
                >
                  <Gift className="w-4 h-4" />
                  <span>دریافت آنی کد تخفیف</span>
                </button>

                <p className="text-[10px] text-slate-400 text-center">
                  با ثبت شماره، پیامک تایید کد تخفیف برای شما ارسال خواهد شد.
                </p>
              </form>
            )}
          </div>
        </div>
      )}

      {/* 2. Special Offer Modal (with 15-min countdown timer) */}
      {isOfferOpen && offerProduct && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="relative w-full max-w-lg bg-white rounded-3xl p-6 shadow-2xl border border-slate-100 animate-in fade-in zoom-in duration-200">
            <button
              onClick={onCloseOffer}
              className="absolute top-4 left-4 p-2 text-slate-400 hover:text-slate-700 rounded-full hover:bg-slate-100 transition-colors cursor-pointer"
              id="close-offer-modal"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Countdown Banner */}
            <div className="bg-gradient-to-r from-rose-500 to-amber-500 text-white rounded-2xl p-3.5 mb-5 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 animate-spin" />
                <span className="text-xs font-bold">مهلت پیشنهاد ویژه خوانندگان این مقاله:</span>
              </div>
              <span className="font-mono font-black text-sm bg-black/30 px-3 py-1 rounded-lg">
                {formatCountdown(timeLeft)}
              </span>
            </div>

            <div className="flex flex-col sm:flex-row items-center gap-5">
              <img
                src={offerProduct.image}
                alt={offerProduct.name}
                className="w-32 h-32 rounded-2xl object-cover border border-slate-200 shrink-0"
              />

              <div className="flex-1 text-center sm:text-right">
                <div className="flex items-center justify-center sm:justify-start gap-1 text-amber-500 text-xs mb-1">
                  <Star className="w-3.5 h-3.5 fill-amber-400" />
                  <span className="font-mono font-bold">{offerProduct.rating}</span>
                  <span className="text-slate-400">(برترین مکمل انتخابی)</span>
                </div>

                <h4 className="font-extrabold text-slate-900 text-sm sm:text-base leading-snug mb-1">
                  {offerProduct.name}
                </h4>
                <p className="text-xs text-slate-500 mb-3">{offerProduct.brand}</p>

                <div className="flex items-center justify-center sm:justify-start gap-3">
                  <span className="text-lg font-black text-rose-600 font-mono">
                    {offerProduct.discountPrice.toLocaleString('fa-IR')} تومان
                  </span>
                  <span className="text-xs text-slate-400 line-through font-mono">
                    {offerProduct.originalPrice.toLocaleString('fa-IR')}
                  </span>
                  <span className="bg-rose-100 text-rose-700 text-[11px] font-bold px-2 py-0.5 rounded-md">
                    {offerProduct.discountPercent}٪ تخفیف
                  </span>
                </div>
              </div>
            </div>

            <div className="mt-6 pt-4 border-t border-slate-100 flex gap-3">
              <button
                onClick={() => {
                  onToast(`محصول با ۴۰٪ تخفیف به سفارش شما پیوست گردید.`);
                  onCloseOffer();
                }}
                className="flex-1 bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold py-3 rounded-xl shadow-md transition-all cursor-pointer flex items-center justify-center gap-1.5"
                id="claim-offer-pack-btn"
              >
                <ShoppingBag className="w-4 h-4" />
                <span>رزرو و دریافت با تخفیف ۴۰٪</span>
              </button>
              <button
                onClick={onCloseOffer}
                className="bg-slate-100 hover:bg-slate-200 text-slate-600 text-xs font-bold px-4 py-3 rounded-xl cursor-pointer"
              >
                انصراف
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 3. Auth Modal (ورود / ثبت‌نام) */}
      {isAuthOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="relative w-full max-w-md bg-white rounded-3xl p-6 shadow-2xl border border-slate-100 animate-in fade-in zoom-in duration-200">
            <button
              onClick={onCloseAuth}
              className="absolute top-4 left-4 p-2 text-slate-400 hover:text-slate-700 rounded-full hover:bg-slate-100 transition-colors cursor-pointer"
              id="close-auth-modal"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Tabs */}
            <div className="flex border-b border-slate-200 mb-5">
              <button
                onClick={() => setAuthTab('login')}
                className={`flex-1 pb-3 text-xs font-bold text-center border-b-2 transition-colors cursor-pointer ${
                  authTab === 'login'
                    ? 'border-rose-600 text-rose-600'
                    : 'border-transparent text-slate-400 hover:text-slate-600'
                }`}
              >
                ورود به حساب کاربری
              </button>
              <button
                onClick={() => setAuthTab('register')}
                className={`flex-1 pb-3 text-xs font-bold text-center border-b-2 transition-colors cursor-pointer ${
                  authTab === 'register'
                    ? 'border-rose-600 text-rose-600'
                    : 'border-transparent text-slate-400 hover:text-slate-600'
                }`}
              >
                عضویت جدید
              </button>
            </div>

            <form onSubmit={handleAuthSubmit} className="space-y-4">
              {authTab === 'register' && (
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">نام و نام خانوادگی</label>
                  <div className="relative">
                    <input
                      type="text"
                      required
                      value={authName}
                      onChange={(e) => setAuthName(e.target.value)}
                      placeholder="نام خود را وارد کنید"
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl pr-9 pl-3.5 py-2.5 text-xs text-slate-800 focus:bg-white focus:outline-hidden focus:border-rose-500"
                    />
                    <User className="w-4 h-4 text-slate-400 absolute right-3 top-3" />
                  </div>
                </div>
              )}

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">شماره تلفن همراه</label>
                <div className="relative">
                  <input
                    type="tel"
                    required
                    dir="ltr"
                    value={authPhone}
                    onChange={(e) => setAuthPhone(e.target.value)}
                    placeholder="۰۹۱۲۳۴۵۶۷۸۹"
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl pr-9 pl-3.5 py-2.5 text-xs text-slate-800 text-left focus:bg-white focus:outline-hidden focus:border-rose-500"
                    id="auth-phone-input"
                  />
                  <Phone className="w-4 h-4 text-slate-400 absolute right-3 top-3" />
                </div>
              </div>

              <button
                type="submit"
                className="w-full bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold py-3 rounded-xl shadow-md transition-all cursor-pointer flex items-center justify-center gap-2 mt-2"
                id="auth-submit-btn"
              >
                <span>{authTab === 'login' ? 'ورود با رمز یکبار مصرف' : 'ثبت‌نام و عضویت در باشگاه'}</span>
                <ArrowLeft className="w-4 h-4" />
              </button>

              <p className="text-[10px] text-slate-400 text-center leading-relaxed">
                با ورود یا ثبت‌نام، تمامی قوانین و شرایط حفظ حریم خصوصی مرکز دارو را می‌پذیرید.
              </p>
            </form>
          </div>
        </div>
      )}

      {/* 4. Drug Clinical Detail Modal */}
      {selectedDrug && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="relative w-full max-w-2xl bg-white rounded-3xl p-6 sm:p-8 shadow-2xl border border-slate-100 max-h-[90vh] overflow-y-auto animate-in fade-in zoom-in duration-200">
            <button
              onClick={onCloseDrug}
              className="absolute top-4 left-4 p-2 text-slate-400 hover:text-slate-700 rounded-full hover:bg-slate-100 transition-colors cursor-pointer"
              id="close-drug-modal"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Header */}
            <div className="border-b border-slate-100 pb-4 mb-4">
              <div className="flex items-center gap-2 mb-2">
                <span className={`text-[11px] font-bold px-2.5 py-0.5 rounded-full font-mono ${
                  selectedDrug.category === 'Rx'
                    ? 'bg-rose-100 text-rose-700'
                    : 'bg-emerald-100 text-emerald-700'
                }`}>
                  {selectedDrug.category === 'Rx' ? 'داروی نسخه‌ای (Rx)' : 'داروی بدون نسخه (OTC)'}
                </span>
                <span className="text-xs text-slate-400 font-mono">{selectedDrug.strength}</span>
              </div>

              <h2 className="text-xl sm:text-2xl font-black text-slate-900">
                {selectedDrug.nameFa}
              </h2>
              <p className="text-xs font-mono text-slate-400 mt-0.5">
                {selectedDrug.nameEn} ({selectedDrug.genericName})
              </p>
            </div>

            {/* Clinical Information Sections */}
            <div className="space-y-4 text-xs sm:text-sm leading-relaxed">
              <div className="bg-slate-50 rounded-2xl p-4 border border-slate-100">
                <h4 className="font-bold text-slate-900 mb-1 text-xs sm:text-sm flex items-center gap-1.5 text-indigo-600">
                  <Pill className="w-4 h-4" />
                  موارد مصرف (Indications):
                </h4>
                <p className="text-slate-600">{selectedDrug.indications}</p>
              </div>

              <div className="bg-slate-50 rounded-2xl p-4 border border-slate-100">
                <h4 className="font-bold text-slate-900 mb-1 text-xs sm:text-sm flex items-center gap-1.5 text-emerald-600">
                  <Check className="w-4 h-4" />
                  دوز و نحوه مصرف پیشنهادی (Dosage):
                </h4>
                <p className="text-slate-600">{selectedDrug.dosage}</p>
              </div>

              <div className="bg-rose-50/80 rounded-2xl p-4 border border-rose-200/80">
                <h4 className="font-bold text-rose-900 mb-1 text-xs sm:text-sm flex items-center gap-1.5">
                  <AlertTriangle className="w-4 h-4 text-rose-600" />
                  موارد منع مصرف و هشدارهای مهم (Contraindications):
                </h4>
                <p className="text-rose-800">{selectedDrug.contraindications}</p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="bg-slate-50 rounded-2xl p-3.5 border border-slate-100">
                  <span className="font-bold text-slate-700 block mb-1 text-xs">مکانیسم اثر:</span>
                  <p className="text-slate-500 text-xs">{selectedDrug.mechanism}</p>
                </div>
                <div className="bg-slate-50 rounded-2xl p-3.5 border border-slate-100">
                  <span className="font-bold text-slate-700 block mb-1 text-xs">عوارض جانبی احتمالی:</span>
                  <p className="text-slate-500 text-xs">{selectedDrug.sideEffects}</p>
                </div>
              </div>

              <div className="text-[11px] text-slate-400 pt-2 flex items-center justify-between">
                <span>تولیدکننده معتبر: {selectedDrug.manufacturer}</span>
                <span>فرم دارویی: {selectedDrug.form}</span>
              </div>
            </div>

            <div className="mt-6 pt-4 border-t border-slate-100">
              <button
                onClick={onCloseDrug}
                className="w-full bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold py-3 rounded-xl transition-colors cursor-pointer"
              >
                بستن راهنمای بالینی
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
