import React, { useState } from 'react';
import { Play, Pause, Headphones, Radio, Volume2 } from 'lucide-react';
import { Interview } from '../types';

interface DoctorInterviewsProps {
  interviews: Interview[];
  onToast: (msg: string) => void;
}

export const DoctorInterviews: React.FC<DoctorInterviewsProps> = ({ interviews, onToast }) => {
  const [activeInterviewId, setActiveInterviewId] = useState<string | null>(null);
  const [progressState, setProgressState] = useState<Record<string, number>>({
    'int-1': 35,
    'int-2': 15,
    'int-3': 0
  });

  const handleToggleAudio = (id: string, title: string) => {
    if (activeInterviewId === id) {
      setActiveInterviewId(null);
      onToast(`پخش مصاحبه صوتی متوقف شد.`);
    } else {
      setActiveInterviewId(id);
      onToast(`در حال پخش پادکست اختصاصی: "${title}"`);
    }
  };

  return (
    <section className="max-w-7xl mx-auto px-4 mt-12" id="doctor-interviews-section">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-purple-600 text-white flex items-center justify-center shadow-md shadow-purple-200">
            <Radio className="w-5 h-5 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl font-bold text-slate-900">مصاحبه اختصاصی با پزشکان و داروسازان</h2>
              <span className="bg-purple-100 text-purple-700 text-[10px] font-bold px-2 py-0.5 rounded-full">
                پادکست کلینیکال
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              ناگفته‌های تجربیات بالینی متخصصان برتر درباره بیماری‌ها و داروهای خاص
            </p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {interviews.map((interview) => {
          const isPlaying = activeInterviewId === interview.id;
          const progress = progressState[interview.id] || 0;

          return (
            <div
              key={interview.id}
              className={`bg-white rounded-3xl p-5 border transition-all flex flex-col justify-between ${
                isPlaying 
                  ? 'border-purple-500 ring-2 ring-purple-100 shadow-md' 
                  : 'border-slate-200/90 hover:border-slate-300 shadow-xs hover:shadow-md'
              }`}
              id={`interview-card-${interview.id}`}
            >
              <div>
                {/* Doctor profile */}
                <div className="flex items-center gap-3 mb-4">
                  <div className="relative">
                    <img
                      src={interview.avatar}
                      alt={interview.doctorName}
                      className="w-13 h-13 rounded-2xl object-cover border-2 border-purple-100 shadow-xs"
                    />
                    <span className="absolute -bottom-1 -right-1 w-4 h-4 bg-emerald-500 rounded-full border-2 border-white"></span>
                  </div>
                  <div>
                    <h3 className="font-bold text-slate-900 text-sm">{interview.doctorName}</h3>
                    <p className="text-purple-600 font-medium text-[11px]">{interview.specialty}</p>
                    <p className="text-slate-400 text-[10px] truncate max-w-[180px]">{interview.hospital}</p>
                  </div>
                </div>

                <h4 className="font-bold text-slate-800 text-xs md:text-sm leading-snug mb-2">
                  {interview.title}
                </h4>

                <p className="text-xs text-slate-500 leading-relaxed line-clamp-3 mb-4">
                  {interview.excerpt}
                </p>
              </div>

              {/* Audio Bar UI */}
              <div className="bg-slate-50 border border-slate-200/70 rounded-2xl p-3.5 mt-2">
                <div className="flex items-center justify-between text-[10px] text-slate-400 mb-2 font-mono">
                  <span className="flex items-center gap-1 text-purple-700 font-bold">
                    <Headphones className="w-3 h-3" />
                    پادکست صوتی
                  </span>
                  <span>{interview.audioDuration}</span>
                </div>

                {/* Progress Bar with simulated audio bars */}
                <div className="flex items-center gap-3">
                  <button
                    onClick={() => handleToggleAudio(interview.id, interview.doctorName)}
                    className={`w-10 h-10 rounded-xl flex items-center justify-center transition-all cursor-pointer ${
                      isPlaying 
                        ? 'bg-purple-600 text-white shadow-md shadow-purple-300 scale-105' 
                        : 'bg-white text-purple-600 hover:bg-purple-50 border border-purple-200'
                    }`}
                    aria-label={isPlaying ? 'توقف پادکست' : 'پخش پادکست'}
                    id={`podcast-play-btn-${interview.id}`}
                  >
                    {isPlaying ? <Pause className="w-5 h-5 fill-current" /> : <Play className="w-5 h-5 fill-current translate-x-0.5" />}
                  </button>

                  <div className="flex-1">
                    {/* Simulated Waveform / Progress */}
                    <div className="h-2 bg-slate-200 rounded-full overflow-hidden relative cursor-pointer"
                      onClick={() => {
                        setProgressState(prev => ({
                          ...prev,
                          [interview.id]: Math.floor(Math.random() * 80) + 10
                        }));
                      }}
                    >
                      <div
                        className="h-full bg-gradient-to-r from-purple-500 to-indigo-500 rounded-full transition-all duration-300"
                        style={{ width: `${isPlaying ? Math.max(progress, 45) : progress}%` }}
                      />
                    </div>

                    <div className="flex items-center justify-between text-[9px] text-slate-400 mt-1 font-mono">
                      <span>{isPlaying ? 'در حال پخش...' : 'آماده پخش'}</span>
                      <span className="flex items-center gap-0.5">
                        <Volume2 className="w-2.5 h-2.5 text-purple-400" />
                        کیفیت عالی ۳۲۰
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
};
