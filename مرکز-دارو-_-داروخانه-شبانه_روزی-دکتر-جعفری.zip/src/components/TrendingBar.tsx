import React from 'react';
import { Flame } from 'lucide-react';
import { TRENDING_TAGS } from '../data';

interface TrendingBarProps {
  onSelectTag: (tag: string) => void;
}

export const TrendingBar: React.FC<TrendingBarProps> = ({ onSelectTag }) => {
  return (
    <div className="max-w-7xl mx-auto px-4 mt-6" id="trending-topics-bar">
      <div className="bg-white rounded-2xl p-3.5 border border-slate-200/80 shadow-xs flex flex-wrap items-center gap-3">
        <div className="flex items-center gap-1.5 text-rose-600 font-bold text-xs shrink-0 px-2 py-1 bg-rose-50 rounded-lg">
          <Flame className="w-4 h-4 text-rose-500 animate-pulse" />
          <span>موضوعات داغ امروز:</span>
        </div>

        <div className="flex items-center gap-2 overflow-x-auto py-1 scrollbar-none flex-1">
          {TRENDING_TAGS.map((tag) => (
            <button
              key={tag}
              onClick={() => onSelectTag(tag.replace('#', ''))}
              className="text-xs text-slate-600 hover:text-rose-600 hover:bg-slate-100 px-2.5 py-1 rounded-full transition-colors whitespace-nowrap cursor-pointer border border-slate-100"
              id={`trending-tag-${tag.replace(/[^a-zA-Z0-9]/g, '')}`}
            >
              {tag}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};
