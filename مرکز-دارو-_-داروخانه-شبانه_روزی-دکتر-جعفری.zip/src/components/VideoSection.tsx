import React, { useState, useRef } from 'react';
import { 
  Play, 
  Pause, 
  Video, 
  ArrowLeft, 
  ArrowUp, 
  Clock, 
  MessageSquare, 
  Volume2, 
  VolumeX, 
  Maximize,
  Download,
  Share2
} from 'lucide-react';
import { VideoItem } from '../types';

interface VideoSectionProps {
  videos: VideoItem[];
  onNavigateCategory: (slug: string) => void;
  onToast: (msg: string) => void;
}

export const VideoSection: React.FC<VideoSectionProps> = ({
  videos,
  onNavigateCategory,
  onToast
}) => {
  const [activeVideoId, setActiveVideoId] = useState<string>(videos[0]?.id || '');
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const videoRef = useRef<HTMLVideoElement>(null);

  const activeVideo = videos.find((v) => v.id === activeVideoId) || videos[0];

  const handleSelectVideo = (video: VideoItem) => {
    setActiveVideoId(video.id);
    setIsPlaying(false);
    if (videoRef.current) {
      videoRef.current.pause();
      videoRef.current.currentTime = 0;
    }
  };

  const togglePlay = () => {
    if (!videoRef.current) return;
    if (isPlaying) {
      videoRef.current.pause();
      setIsPlaying(false);
    } else {
      videoRef.current.play().then(() => {
        setIsPlaying(true);
      }).catch(() => {
        setIsPlaying(true);
      });
    }
  };

  const toggleMute = () => {
    if (!videoRef.current) return;
    videoRef.current.muted = !isMuted;
    setIsMuted(!isMuted);
  };

  const handleFullscreen = () => {
    if (!videoRef.current) return;
    if (videoRef.current.requestFullscreen) {
      videoRef.current.requestFullscreen();
    }
  };

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <section className="max-w-7xl mx-auto px-4 mt-12" id="digikala-video-hub">
      {/* Section Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 mb-6 pb-4 border-b border-slate-200">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-blue-600 text-white flex items-center justify-center shadow-md shadow-blue-200">
            <Video className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl font-bold text-slate-900">جدیدترین ویدیوها</h2>
              <span className="bg-blue-100 text-blue-700 text-[10px] font-bold px-2 py-0.5 rounded-full">
                دیجی‌کالا مگ هلث
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              آموزش‌های تصویری داروسازان و بررسی علمی مکمل‌ها و تجهیزات پزشکی
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={scrollToTop}
            className="flex items-center gap-1 text-xs text-slate-600 hover:text-blue-600 bg-slate-100 hover:bg-slate-200 px-3 py-1.5 rounded-lg transition-colors cursor-pointer"
            id="video-scroll-top-btn"
          >
            <ArrowUp className="w-3.5 h-3.5" />
            <span>بالای صفحه</span>
          </button>
          <button
            onClick={() => onNavigateCategory('media')}
            className="flex items-center gap-1 text-xs font-bold text-blue-600 hover:text-blue-700 bg-blue-50 hover:bg-blue-100 px-3.5 py-1.5 rounded-lg transition-colors cursor-pointer"
            id="video-view-all-btn"
          >
            <span>ویدیوهای بیشتر</span>
            <ArrowLeft className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* 2-Column Digikala Mag Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 bg-white rounded-3xl p-4 md:p-6 border border-slate-200 shadow-sm">
        {/* Main Large Player Column (7 Cols on lg) */}
        <div className="lg:col-span-7 flex flex-col justify-between" id="main-video-player-container">
          <div>
            {/* Video Canvas / Player */}
            <div className="relative aspect-16/9 rounded-2xl overflow-hidden bg-slate-950 shadow-inner group">
              <video
                ref={videoRef}
                src={activeVideo.videoUrl}
                poster={activeVideo.thumbnail}
                className="w-full h-full object-cover"
                onEnded={() => setIsPlaying(false)}
                playsInline
              />

              {/* Watermark */}
              <div className="absolute top-4 left-4 z-20 flex items-center gap-1.5 bg-black/60 backdrop-blur-md text-white text-[10px] font-bold px-2.5 py-1 rounded-md tracking-wider">
                <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping"></span>
                MARKAZDAROO TV
              </div>

              {/* Category Badge */}
              <div className="absolute top-4 right-4 z-20 bg-rose-600 text-white text-xs font-bold px-3 py-1 rounded-full shadow-md">
                ویدیو سلامت
              </div>

              {/* Big Central Play/Pause Overlay Button */}
              {!isPlaying && (
                <div 
                  onClick={togglePlay}
                  className="absolute inset-0 z-20 flex items-center justify-center bg-black/35 backdrop-blur-[1px] cursor-pointer group-hover:bg-black/45 transition-all"
                >
                  <div className="w-16 h-16 rounded-full bg-rose-600 hover:bg-rose-500 text-white flex items-center justify-center shadow-xl shadow-rose-900/50 transform group-hover:scale-110 transition-transform">
                    <Play className="w-8 h-8 translate-x-0.5 fill-white" />
                  </div>
                </div>
              )}

              {/* Custom Overlay Controls */}
              <div className="absolute bottom-0 inset-x-0 z-20 p-3 bg-gradient-to-t from-black/80 via-black/40 to-transparent flex items-center justify-between text-white text-xs">
                <div className="flex items-center gap-3">
                  <button
                    onClick={togglePlay}
                    className="p-1 hover:text-rose-400 transition-colors cursor-pointer"
                    aria-label={isPlaying ? 'توقف ویدیو' : 'پخش ویدیو'}
                  >
                    {isPlaying ? <Pause className="w-5 h-5 fill-white" /> : <Play className="w-5 h-5 fill-white" />}
                  </button>
                  <button
                    onClick={toggleMute}
                    className="p-1 hover:text-rose-400 transition-colors cursor-pointer"
                    aria-label={isMuted ? 'صدا روشن' : 'بی‌صدا'}
                  >
                    {isMuted ? <VolumeX className="w-5 h-5" /> : <Volume2 className="w-5 h-5" />}
                  </button>
                  <span className="text-[11px] font-mono text-slate-300">
                    {activeVideo.duration}
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={handleFullscreen}
                    className="p-1 hover:text-rose-400 transition-colors cursor-pointer"
                    aria-label="تمام صفحه"
                  >
                    <Maximize className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>

            {/* Video Details */}
            <div className="mt-4">
              <h3 className="text-base md:text-lg font-bold text-slate-900 leading-snug">
                {activeVideo.title}
              </h3>

              {/* Turquoise Accent Separator Line */}
              <div className="w-16 h-1 bg-teal-500 rounded-full my-3" />

              <p className="text-xs md:text-sm text-slate-600 leading-relaxed line-clamp-3">
                {activeVideo.description}
              </p>
            </div>
          </div>

          {/* Video Metadata & Action Bar */}
          <div className="mt-5 pt-4 border-t border-slate-100 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2.5">
              <img
                src={activeVideo.authorAvatar}
                alt={activeVideo.author}
                className="w-8 h-8 rounded-full object-cover border border-slate-200"
              />
              <div>
                <p className="text-xs font-bold text-slate-800">{activeVideo.author}</p>
                <div className="flex items-center gap-2 text-[10px] text-slate-400">
                  <span>{activeVideo.date}</span>
                  <span>•</span>
                  <span className="flex items-center gap-1">
                    <MessageSquare className="w-3 h-3" />
                    {activeVideo.commentsCount} نظر
                  </span>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => onToast('لینک اشتراک‌گذاری این ویدیو کپی شد.')}
                className="p-2 rounded-lg text-slate-500 hover:text-slate-800 hover:bg-slate-100 transition-colors cursor-pointer"
                title="اشتراک‌گذاری"
              >
                <Share2 className="w-4 h-4" />
              </button>
              <button
                onClick={() => onToast('دانلود نسخه با کیفیت ۱۰۸۰ با موفقیت آغاز شد.')}
                className="inline-flex items-center gap-1.5 bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold px-4 py-2 rounded-xl transition-all cursor-pointer"
                id="download-video-btn"
              >
                <Download className="w-3.5 h-3.5" />
                <span>دانلود ویدیوی کامل</span>
              </button>
            </div>
          </div>
        </div>

        {/* Playlist Column (5 Cols on lg) */}
        <div className="lg:col-span-5 flex flex-col justify-between border-t lg:border-t-0 lg:border-r lg:pr-6 border-slate-100">
          <div>
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-bold text-slate-700">لیست پخش ویدیوهای برگزیده</span>
              <span className="text-[11px] text-slate-400 font-mono">({videos.length} ویدیو)</span>
            </div>

            <div className="space-y-2.5 max-h-[460px] overflow-y-auto pr-1">
              {videos.map((vid) => {
                const isActive = vid.id === activeVideoId;
                return (
                  <div
                    key={vid.id}
                    onClick={() => handleSelectVideo(vid)}
                    className={`flex items-center gap-3 p-2.5 rounded-2xl cursor-pointer transition-all ${
                      isActive
                        ? 'border-r-4 border-r-rose-600 bg-rose-50/70 shadow-xs'
                        : 'hover:bg-slate-50 border-r-4 border-r-transparent'
                    }`}
                    id={`video-playlist-item-${vid.id}`}
                  >
                    {/* Thumbnail with overlay duration */}
                    <div className="relative w-24 h-16 rounded-xl overflow-hidden bg-slate-900 shrink-0">
                      <img
                        src={vid.thumbnail}
                        alt={vid.title}
                        className="w-full h-full object-cover"
                      />
                      <div className="absolute inset-0 bg-black/25 flex items-center justify-center">
                        <div className={`w-6 h-6 rounded-full flex items-center justify-center ${
                          isActive ? 'bg-rose-600 text-white' : 'bg-white/80 text-slate-800'
                        }`}>
                          <Play className="w-3 h-3 translate-x-0.5 fill-current" />
                        </div>
                      </div>
                      <span className="absolute bottom-1 left-1 bg-black/75 text-white text-[9px] font-mono px-1 rounded-sm">
                        {vid.duration}
                      </span>
                    </div>

                    {/* Text Details */}
                    <div className="flex-1 min-w-0">
                      <h4 className={`text-xs leading-snug line-clamp-2 ${
                        isActive ? 'font-bold text-rose-900' : 'text-slate-800'
                      }`}>
                        {vid.title}
                      </h4>
                      <div className="flex items-center gap-2 mt-1 text-[10px] text-slate-400">
                        <span>{vid.author}</span>
                        <span>•</span>
                        <span>{vid.date}</span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-100 bg-slate-50/80 rounded-xl p-3 text-center">
            <p className="text-[11px] text-slate-600">
              ویدیوهای بیشتر را در کانال آپارات و یوتیوب مرکز دارو تماشا کنید
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};
