import React from 'react';
import { Pill, PhoneCall, MapPin, Mail, ShieldCheck, Heart } from 'lucide-react';
import { CATEGORIES } from '../data';

interface FooterProps {
  onNavigate: (view: string, param?: string) => void;
  onOpenDiscount: () => void;
  onOpenChat: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate, onOpenDiscount, onOpenChat }) => {
  return (
    <footer className="bg-slate-900 text-slate-300 mt-20 border-t border-slate-800" id="site-footer">
      {/* Top Banner */}
      <div className="bg-slate-950/60 py-6 border-b border-slate-800">
        <div className="max-w-7xl mx-auto px-4 flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-rose-600/20 border border-rose-500/30 text-rose-400 flex items-center justify-center">
              <Pill className="w-5 h-5 rotate-45" />
            </div>
            <div>
              <h3 className="font-extrabold text-white text-base">مرکز دارو | داروخانه شبانه‌روزی دکتر جعفری</h3>
              <p className="text-xs text-slate-400">مجله تخصصی سلامت، داروشناسی و مشاوره داروساز کشیک</p>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <a
              href="tel:02188884500"
              className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold px-4 py-2.5 rounded-xl transition-all shadow-md font-mono"
              id="footer-emergency-phone"
            >
              <PhoneCall className="w-4 h-4" />
              <span>پشتیبانی شبانه‌روزی: ۰۲۱-۸۸۸۸۴۵۰۰</span>
            </a>
          </div>
        </div>
      </div>

      {/* Main 4-Column Grid */}
      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Col 1: About */}
          <div>
            <h4 className="font-bold text-white text-sm mb-4 border-r-2 border-r-rose-500 pr-2.5">
              درباره مرکز دارو
            </h4>
            <p className="text-xs text-slate-400 leading-relaxed mb-4">
              داروخانه شبانه‌روزی دکتر جعفری با هدف ارتقای سواد سلامت هم‌وطنان و ارائه دسترسی سریع و آسان به اطلاعات دارویی معتبر و مورد تأیید وزارت بهداشت و سازمان غذا و دارو راه‌اندازی گردیده است.
            </p>
            <div className="flex items-center gap-2 text-xs text-emerald-400">
              <ShieldCheck className="w-4 h-4 shrink-0" />
              <span>دارای مجوز رسمی داروخانه شبانه‌روزی</span>
            </div>
          </div>

          {/* Col 2: Categories */}
          <div>
            <h4 className="font-bold text-white text-sm mb-4 border-r-2 border-r-rose-500 pr-2.5">
              دسته‌بندی‌های مجله سلامت
            </h4>
            <ul className="space-y-2 text-xs text-slate-400">
              {CATEGORIES.slice(1).map((cat) => (
                <li key={cat.id}>
                  <button
                    onClick={() => onNavigate('category', cat.slug)}
                    className="hover:text-rose-400 transition-colors cursor-pointer"
                  >
                    {cat.name}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Col 3: Services */}
          <div>
            <h4 className="font-bold text-white text-sm mb-4 border-r-2 border-r-rose-500 pr-2.5">
              خدمات شبانه‌روزی
            </h4>
            <ul className="space-y-2 text-xs text-slate-400">
              <li>
                <button onClick={onOpenChat} className="hover:text-rose-400 transition-colors cursor-pointer">
                  مشاوره هوشمند با داروساز کشیک
                </button>
              </li>
              <li>
                <button onClick={onOpenDiscount} className="hover:text-rose-400 transition-colors cursor-pointer">
                  دریافت بن تخفیف ۱۰۰ هزار تومانی
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('home')} className="hover:text-rose-400 transition-colors cursor-pointer">
                  استعلام بانک اطلاعات و دوز داروها
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('category', 'media')} className="hover:text-rose-400 transition-colors cursor-pointer">
                  ویدیوهای آموزشی دیجی‌کالا مگ هلث
                </button>
              </li>
              <li>
                <span className="text-slate-500">تحویل فوری نسخ دارویی در استان تهران</span>
              </li>
            </ul>
          </div>

          {/* Col 4: Contact & Badges */}
          <div>
            <h4 className="font-bold text-white text-sm mb-4 border-r-2 border-r-rose-500 pr-2.5">
              ارتباط و نشانی
            </h4>
            <div className="space-y-3 text-xs text-slate-400">
              <div className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-rose-500 shrink-0 mt-0.5" />
                <span>تهران، خیابان ولیعصر، بالاتر از شهید بهشتی، نرسیده به میدان ونک، پلاک ۲۴</span>
              </div>
              <div className="flex items-center gap-2">
                <PhoneCall className="w-4 h-4 text-emerald-400 shrink-0" />
                <span className="font-mono">۰۲۱-۸۸۸۸۴۵۰۰ (۱۰ خط ویژه)</span>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-amber-400 shrink-0" />
                <span className="font-mono">info@markazdaroo.ir</span>
              </div>
            </div>

            {/* Trust Badges */}
            <div className="mt-6 flex items-center gap-2.5">
              <div className="bg-slate-800 p-2 rounded-xl border border-slate-700 text-center flex-1">
                <ShieldCheck className="w-6 h-6 text-emerald-400 mx-auto mb-1" />
                <span className="text-[9px] text-slate-300 block">سازمان غذا و دارو</span>
              </div>
              <div className="bg-slate-800 p-2 rounded-xl border border-slate-700 text-center flex-1">
                <ShieldCheck className="w-6 h-6 text-blue-400 mx-auto mb-1" />
                <span className="text-[9px] text-slate-300 block">وزارت بهداشت</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Copyright */}
      <div className="bg-slate-950 py-4 border-t border-slate-800 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <p>© {new Date().toLocaleDateString('fa-IR', { year: 'numeric' })} تمامی حقوق مادی و معنوی برای مجله پزشکی و داروخانه شبانه‌روزی دکتر جعفری محفوظ است.</p>
          <p className="flex items-center gap-1 text-[11px]">
            طراحی شده با استانداردهای مدرن سلامت‌محور (Health-Tech)
          </p>
        </div>
      </div>
    </footer>
  );
};
