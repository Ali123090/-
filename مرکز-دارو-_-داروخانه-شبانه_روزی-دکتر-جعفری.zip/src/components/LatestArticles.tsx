import React from 'react';
import { Clock, MessageSquare, ShieldCheck, ArrowLeft, BookOpen } from 'lucide-react';
import { Article } from '../types';

interface LatestArticlesProps {
  articles: Article[];
  onSelectArticle: (slug: string) => void;
}

export const LatestArticles: React.FC<LatestArticlesProps> = ({ articles, onSelectArticle }) => {
  return (
    <section className="max-w-7xl mx-auto px-4 mt-12" id="latest-articles-section">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-rose-600 text-white flex items-center justify-center shadow-md shadow-rose-200">
            <BookOpen className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-slate-900">جدیدترین مقالات مجله مرکز دارو</h2>
            <p className="text-xs text-slate-500">تازه‌ترین انتشارات تحریریه داروسازی و پزشکان همکار</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {articles.map((art) => (
          <article
            key={art.id}
            onClick={() => onSelectArticle(art.slug)}
            className="group bg-white rounded-3xl border border-slate-200/90 overflow-hidden shadow-xs hover:shadow-lg transition-all hover:-translate-y-1 cursor-pointer flex flex-col justify-between"
            id={`latest-article-${art.id}`}
          >
            <div>
              <div className="relative aspect-16/10 overflow-hidden bg-slate-100">
                <img
                  src={art.imageUrl}
                  alt={art.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <span className="absolute top-3 right-3 bg-white/95 backdrop-blur-xs text-rose-600 font-bold text-[11px] px-3 py-1 rounded-full shadow-xs">
                  {art.category}
                </span>
                {art.verifiedDoctor && (
                  <span className="absolute bottom-3 left-3 bg-emerald-600/90 backdrop-blur-xs text-white text-[10px] font-medium px-2.5 py-0.5 rounded-full flex items-center gap-1 shadow-xs">
                    <ShieldCheck className="w-3.5 h-3.5" />
                    تأییدیه بالینی
                  </span>
                )}
              </div>

              <div className="p-5">
                <div className="flex items-center gap-3 text-[11px] text-slate-400 mb-2">
                  <span className="flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5" />
                    {art.readTime}
                  </span>
                  <span>•</span>
                  <span>{art.date}</span>
                </div>

                <h3 className="font-bold text-slate-900 text-sm md:text-base leading-snug group-hover:text-rose-600 transition-colors line-clamp-2 mb-2.5">
                  {art.title}
                </h3>

                <p className="text-xs text-slate-500 line-clamp-2 leading-relaxed">
                  {art.excerpt}
                </p>
              </div>
            </div>

            <div className="px-5 pb-5 pt-3 border-t border-slate-100 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <img
                  src={art.authorAvatar}
                  alt={art.author}
                  className="w-7 h-7 rounded-full object-cover border border-slate-200"
                />
                <div>
                  <p className="text-[11px] font-bold text-slate-700">{art.author}</p>
                  <p className="text-[10px] text-slate-400 truncate max-w-[120px]">{art.authorRole}</p>
                </div>
              </div>

              <span className="text-rose-600 text-xs font-bold flex items-center gap-1 group-hover:translate-x-[-3px] transition-transform">
                <span>مطالعه مقاله</span>
                <ArrowLeft className="w-3.5 h-3.5" />
              </span>
            </div>
          </article>
        ))}
      </div>
    </section>
  );
};
