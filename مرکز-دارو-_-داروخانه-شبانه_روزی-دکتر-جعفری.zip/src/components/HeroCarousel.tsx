import React, { useState, useEffect } from 'react';
import { ChevronRight, ChevronLeft, Clock, ArrowLeft, ShieldCheck } from 'lucide-react';
import { HERO_SLIDES } from '../data';

interface HeroCarouselProps {
  onSelectArticle: (slug: string) => void;
}

export const HeroCarousel: React.FC<HeroCarouselProps> = ({ onSelectArticle }) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPaused, setIsPaused] = useState(false);

  useEffect(() => {
    if (isPaused) return;
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % HERO_SLIDES.length);
    }, 6000);
    return () => clearInterval(interval);
  }, [isPaused]);

  const prevSlide = () => {
    setCurrentIndex((prev) => (prev === 0 ? HERO_SLIDES.length - 1 : prev - 1));
  };

  const nextSlide = () => {
    setCurrentIndex((prev) => (prev + 1) % HERO_SLIDES.length);
  };

  const currentSlide = HERO_SLIDES[currentIndex];

  return (
    <section 
      className="relative max-w-7xl mx-auto px-4 mt-4"
      onMouseEnter={() => setIsPaused(true)}
      onMouseLeave={() => setIsPaused(false)}
      id="hero-carousel-section"
    >
      <div className="relative overflow-hidden rounded-3xl bg-slate-900 text-white min-h-[360px] md:min-h-[420px] flex items-center shadow-xl">
        {/* Background Image with Dark Overlay Gradient */}
        <div 
          className="absolute inset-0 bg-cover bg-center transition-all duration-700 ease-out transform scale-105"
          style={{ backgroundImage: `url(${currentSlide.image})` }}
        />
        <div className="absolute inset-0 bg-gradient-to-r from-slate-950 via-slate-900/85 to-transparent md:to-slate-900/40" />

        {/* Slide Content */}
        <div className="relative z-10 max-w-2xl px-6 md:px-12 py-10 flex flex-col justify-center">
          <div className="flex items-center gap-2 mb-3">
            <span className="bg-rose-600/90 backdrop-blur-md text-white text-xs font-bold px-3 py-1 rounded-full inline-flex items-center gap-1 shadow-xs">
              <ShieldCheck className="w-3.5 h-3.5" />
              {currentSlide.badge}
            </span>
            <span className="text-slate-300 text-xs flex items-center gap-1 font-medium">
              <Clock className="w-3.5 h-3.5" />
              {currentSlide.readTime}
            </span>
          </div>

          <h1 className="text-2xl md:text-3xl lg:text-4xl font-extrabold text-white leading-tight mb-4 tracking-tight drop-shadow-sm">
            {currentSlide.title}
          </h1>

          <p className="text-slate-200 text-xs md:text-sm line-clamp-3 leading-relaxed mb-6 max-w-xl">
            {currentSlide.subtitle}
          </p>

          <div className="flex items-center gap-4">
            <button
              onClick={() => onSelectArticle(currentSlide.articleSlug)}
              className="inline-flex items-center gap-2 bg-rose-600 hover:bg-rose-700 text-white text-xs md:text-sm font-semibold px-5 py-2.5 rounded-full shadow-lg shadow-rose-900/40 transition-all cursor-pointer"
              id="hero-read-article-btn"
            >
              <span>مطالعه گزارش کامل</span>
              <ArrowLeft className="w-4 h-4" />
            </button>
            <span className="text-xs text-slate-400">
              نویسنده: <strong className="text-white font-medium">{currentSlide.author}</strong>
            </span>
          </div>
        </div>

        {/* Carousel Arrow Controls */}
        <div className="absolute left-4 bottom-6 z-20 flex items-center gap-2">
          <button
            onClick={nextSlide}
            className="w-10 h-10 rounded-full bg-white/20 hover:bg-white/30 backdrop-blur-md flex items-center justify-center text-white transition-all cursor-pointer"
            aria-label="اسلاید بعدی"
            id="hero-carousel-next-btn"
          >
            <ChevronRight className="w-5 h-5" />
          </button>
          <button
            onClick={prevSlide}
            className="w-10 h-10 rounded-full bg-white/20 hover:bg-white/30 backdrop-blur-md flex items-center justify-center text-white transition-all cursor-pointer"
            aria-label="اسلاید قبلی"
            id="hero-carousel-prev-btn"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
        </div>

        {/* Indicator Dots */}
        <div className="absolute right-6 bottom-6 z-20 flex items-center gap-1.5">
          {HERO_SLIDES.map((slide, idx) => (
            <button
              key={slide.id}
              onClick={() => setCurrentIndex(idx)}
              className={`h-2 rounded-full transition-all cursor-pointer ${
                idx === currentIndex ? 'w-8 bg-rose-500' : 'w-2 bg-white/40 hover:bg-white/70'
              }`}
              aria-label={`اسلاید ${idx + 1}`}
              id={`hero-dot-${idx}`}
            />
          ))}
        </div>
      </div>
    </section>
  );
};
