import React, { useState } from 'react';
import { Gift, CheckCircle2, ArrowLeft, ShieldCheck } from 'lucide-react';

interface NewsletterBannerProps {
  onClaimDiscount: (phone: string) => void;
}

export const NewsletterBanner: React.FC<NewsletterBannerProps> = ({ onClaimDiscount }) => {
  const [phone, setPhone] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!phone.trim()) return;
    onClaimDiscount(phone);
    setSubmitted(true);
  };

  return (
    <section className="max-w-7xl mx-auto px-4 mt-14" id="newsletter-club-section">
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-rose-600 via-rose-700 to-indigo-900 text-white p-6 md:p-10 shadow-xl">
        {/* Decorative background circles */}
        <div className="absolute top-0 right-0 -translate-y-12 translate-x-12 w-64 h-64 bg-white/10 rounded-full blur-2xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 translate-y-12 -translate-x-12 w-64 h-64 bg-rose-400/20 rounded-full blur-2xl pointer-events-none" />

        <div className="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          <div className="lg:col-span-7">
            <span className="inline-flex items-center gap-1.5 bg-white/20 backdrop-blur-md text-amber-300 text-xs font-bold px-3 py-1 rounded-full mb-3 shadow-xs">
              <Gift className="w-3.5 h-3.5" />
              باشگاه مشتریان و سلامت مرکز دارو
            </span>

            <h2 className="text-xl md:text-3xl font-black leading-tight text-white mb-3">
              ۱۰۰,۰۰۰ تومان هدیه نقدی اولین خرید از داروخانه
            </h2>

            <p className="text-xs md:text-sm text-rose-100 leading-relaxed max-w-xl">
              شماره همراه خود را وارد کنید تا علاوه بر دریافت آنی کد تخفیف اختصاصی، هفتگی تازه‌ترین مقالات پزشکی و یادآور زمان مصرف داروها را دریافت کنید.
            </p>
          </div>

          <div className="lg:col-span-5">
            {submitted ? (
              <div className="bg-white/15 backdrop-blur-md border border-white/25 rounded-2xl p-5 text-center">
                <CheckCircle2 className="w-10 h-10 text-emerald-400 mx-auto mb-2" />
                <h4 className="font-bold text-white text-base">کد تخفیف شما با موفقیت ارسال شد!</h4>
                <p className="text-xs text-rose-100 mt-1">کد: <strong className="font-mono text-amber-300 text-sm">SALAMAT100</strong></p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl p-4 sm:p-5">
                <div className="flex flex-col sm:flex-row gap-2.5">
                  <input
                    type="tel"
                    placeholder="شماره موبایل (مثلاً ۰۹۱۲۳۴۵۶۷۸۹)"
                    dir="ltr"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    required
                    className="flex-1 bg-white text-slate-800 placeholder-slate-400 text-sm rounded-xl px-4 py-3 focus:outline-hidden focus:ring-2 focus:ring-amber-400 text-left"
                    id="newsletter-phone-input"
                  />
                  <button
                    type="submit"
                    className="bg-amber-400 hover:bg-amber-300 text-slate-900 text-xs font-bold px-5 py-3 rounded-xl shadow-md transition-all flex items-center justify-center gap-1.5 cursor-pointer shrink-0"
                    id="newsletter-submit-btn"
                  >
                    <span>دریافت هدیه</span>
                    <ArrowLeft className="w-4 h-4" />
                  </button>
                </div>
                <p className="text-[10px] text-rose-200 mt-2.5 text-center flex items-center justify-center gap-1">
                  <ShieldCheck className="w-3 h-3 text-emerald-400" />
                  اطلاعات شما محفوظ است و پیامک تبلیغاتی ارسال نمی‌شود.
                </p>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};
