import React, { useState, useRef, useEffect } from 'react';
import { Bot, X, Send, Sparkles, User, ShieldAlert, RotateCcw } from 'lucide-react';
import { ChatMessage } from '../types';

interface AIChatBotProps {
  isOpen: boolean;
  onClose: () => void;
  onToggle: () => void;
}

const INITIAL_MESSAGES: ChatMessage[] = [
  {
    id: 'msg-1',
    sender: 'bot',
    text: 'سلام! من «دستیار هوشمند داروساز» داروخانه دکتر جعفری هستم. چطور می‌توانم در مورد تداخلات دارویی، بهترین زمان مصرف مکمل‌ها یا عوارض داروها راهنمایی‌تان کنم؟',
    timestamp: 'هم‌اکنون',
    suggestions: [
      'زمان مصرف قرص زینک پلاس؟',
      'تداخل دارویی وارفارین با ویتامین K؟',
      'عوارض و زمان قرص ناپروکسن؟',
      'دوز ایمن مکمل ویتامین D3؟'
    ]
  }
];

export const AIChatBot: React.FC<AIChatBotProps> = ({ isOpen, onClose, onToggle }) => {
  const [messages, setMessages] = useState<ChatMessage[]>(INITIAL_MESSAGES);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (isOpen) {
      chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, isOpen, isTyping]);

  const generateBotReply = (userQuery: string): string => {
    const q = userQuery.toLowerCase();

    if (q.includes('زینک') || q.includes('روی')) {
      return '💊 **پاسخ داروساز در مورد زینک:**\nبهترین زمان جذب زینک، ۱ ساعت قبل یا ۲ ساعت بعد از غذا با یک لیوان آب است. اما اگر دچار تهوع شدید، بلافاصله **بعد از ناهار** میل کنید.\n\n⚠️ **تداخل مهم:** حداقل ۳ ساعت با قرص آهن و محصولات لبنی فاصله بگذارید.';
    }

    if (q.includes('وارفارین') || q.includes('کومادین')) {
      return '⚠️ **هشدار بالینی وارفارین:**\nوارفارین داروی ضدانعقاد با شاخص درمانی بسیار باریک است. سبزیجات برگ سبز تیره (اسفناج، بروکلی، کاهو) سرشار از ویتامین K هستند و اثر وارفارین را خنثی می‌کنند. همچنین مصرف آسپرین یا ژلوفن همزمان با وارفارین خطر خونریزی حاد را به شدت بالا می‌برد.';
    }

    if (q.includes('ناپروکسن') || q.includes('مسکن') || q.includes('ژلوفن')) {
      return '💊 **نحوه مصرف ناپروکسن:**\nناپروکسن یک ضدالتهاب غیراستروئیدی (NSAID) است. برای جلوگیری از زخم یا خونریزی معده، حتماً **همراه با غذا یا شیر و یک لیوان کامل آب** مصرف شود. افراد دارای سابقه زخم فعال گوارشی یا نارسایی کلیه باید از مصرف آن پرهیز نمایند.';
    }

    if (q.includes('ویتامین دی') || q.includes('ویتامین d') || q.includes('d3')) {
      return '☀️ **دوز و مصرف ویتامین D:**\nویتامین D محلول در چربی است؛ بنابراین حتماً همراه با وعده غذایی حاوی چربی سالم (روغن زیتون یا تخم‌مرغ) میل شود.\n- پرل ۵۰,۰۰۰ واحدی معمولاً برای پیشگیری ماهانه ۱ عدد تجویز می‌شود.\n- در صورت کمبود شدید طبق آزمایش خون، هفته‌ای یک عدد به مدت ۶ الی ۸ هفته تحت نظر پزشک مصرف می‌گردد.';
    }

    if (q.includes('کراتین') || q.includes('ریزش مو')) {
      return '🏋️ **کراتین و ریزش مو:**\nشایعه ریزش مو ناشی از یک مطالعه در سال ۲۰۰۹ بود. ده‌ها تحقیق مستقل دانشگاهی جدیدتر نشان داده‌اند کراتین خالص مونوهیدرات اگر در دوز استاندارد (روزانه ۳ الی ۵ گرم) مصرف شود، به طور مستقیم سبب طاسی نمی‌شود مگر در افرادی با زمینه ژنتیکی شدید حساسیت به DHT.';
    }

    if (q.includes('آموکسی') || q.includes('آنتی بیوتیک') || q.includes('سرماخوردگی')) {
      return '🩺 **پروتکل آنتی‌بیوتیک‌ها:**\nسرماخوردگی و آنفولانزا عفونت‌های ویروسی هستند و آنتی‌بیوتیک‌هایی نظیر آموکسی‌سیلین روی ویروس‌ها بی‌اثرند. مصرف نابجا باعث مقاومت باکتریایی و از بین رفتن باکتری‌های مفید روده می‌شود. آنتی‌بیوتیک تنها در صورت تایید عفونت باکتریایی توسط پزشک تجویز می‌شود.';
    }

    return `متشکرم از سؤالتان. برای راهنمایی دقیق‌تر در مورد "${userQuery}": لطفاً دوز مصرفی، سن بیمار و داروهای همزمانی که مصرف می‌کنید را بفرمایید تا بررسی دقیق‌تری از نظر تداخلات فارماکولوژی انجام دهم.`;
  };

  const handleSend = (textToSend?: string) => {
    const text = textToSend || input;
    if (!text.trim()) return;

    const userMsg: ChatMessage = {
      id: `msg-${Date.now()}`,
      sender: 'user',
      text,
      timestamp: new Date().toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' })
    };

    setMessages((prev) => [...prev, userMsg]);
    if (!textToSend) setInput('');
    setIsTyping(true);

    setTimeout(() => {
      const reply = generateBotReply(text);
      const botMsg: ChatMessage = {
        id: `msg-${Date.now() + 1}`,
        sender: 'bot',
        text: reply,
        timestamp: new Date().toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' })
      };
      setMessages((prev) => [...prev, botMsg]);
      setIsTyping(false);
    }, 700);
  };

  return (
    <>
      {/* Floating Toggle Button */}
      <div className="fixed bottom-6 left-6 z-40">
        <button
          onClick={onToggle}
          className="relative group w-14 h-14 rounded-full bg-gradient-to-tr from-rose-600 to-rose-500 hover:from-rose-700 hover:to-rose-600 text-white shadow-xl shadow-rose-500/40 flex items-center justify-center transition-all transform hover:scale-105 cursor-pointer"
          aria-label="مشاوره با داروساز هوشمند"
          id="floating-ai-pharmacist-btn"
        >
          <Bot className="w-7 h-7" />
          <span className="absolute top-0 right-0 w-4 h-4 bg-emerald-400 rounded-full border-2 border-white animate-pulse"></span>
        </button>
      </div>

      {/* Chat Window */}
      {isOpen && (
        <div 
          className="fixed bottom-22 left-6 z-50 w-[92vw] sm:w-[400px] h-[540px] max-h-[80vh] bg-white rounded-3xl shadow-2xl border border-slate-200 flex flex-col overflow-hidden animate-in fade-in slide-in-from-bottom-5 duration-200"
          id="ai-pharmacist-chat-window"
        >
          {/* Header */}
          <div className="bg-gradient-to-r from-slate-900 to-rose-950 text-white p-4 flex items-center justify-between border-b border-rose-900/30">
            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-2xl bg-rose-600/80 border border-rose-400/40 flex items-center justify-center">
                <Bot className="w-5 h-5 text-white" />
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <h3 className="font-bold text-sm">دستیار داروساز هوشمند</h3>
                  <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
                </div>
                <p className="text-[10px] text-rose-200">پاسخگویی بر پایه مرجع داروشناسی و فارماکوپه</p>
              </div>
            </div>

            <button
              onClick={onClose}
              className="p-1.5 text-slate-300 hover:text-white rounded-lg hover:bg-white/10 transition-colors cursor-pointer"
              id="close-chat-window"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Messages Body */}
          <div className="flex-1 p-4 overflow-y-auto space-y-3.5 bg-slate-50/70 text-xs">
            {messages.map((msg) => {
              const isBot = msg.sender === 'bot';
              return (
                <div
                  key={msg.id}
                  className={`flex items-start gap-2.5 ${isBot ? 'justify-start' : 'justify-end'}`}
                >
                  {isBot && (
                    <div className="w-7 h-7 rounded-xl bg-rose-100 text-rose-700 flex items-center justify-center shrink-0 mt-0.5">
                      <Bot className="w-4 h-4" />
                    </div>
                  )}

                  <div className={`max-w-[85%] rounded-2xl p-3 leading-relaxed ${
                    isBot 
                      ? 'bg-white text-slate-800 border border-slate-200 shadow-2xs' 
                      : 'bg-rose-600 text-white rounded-tr-xs shadow-xs'
                  }`}>
                    <div className="whitespace-pre-wrap">{msg.text}</div>
                    <span className={`block text-[9px] mt-1 font-mono ${isBot ? 'text-slate-400' : 'text-rose-200 text-left'}`}>
                      {msg.timestamp}
                    </span>

                    {/* Chips suggestions if available on bot message */}
                    {msg.suggestions && msg.suggestions.length > 0 && (
                      <div className="mt-3 pt-2 border-t border-slate-100 flex flex-wrap gap-1.5">
                        {msg.suggestions.map((chip, idx) => (
                          <button
                            key={idx}
                            onClick={() => handleSend(chip)}
                            className="bg-rose-50 hover:bg-rose-100 text-rose-700 text-[10px] font-semibold px-2.5 py-1 rounded-lg transition-colors cursor-pointer text-right"
                          >
                            {chip}
                          </button>
                        ))}
                      </div>
                    )}
                  </div>

                  {!isBot && (
                    <div className="w-7 h-7 rounded-xl bg-slate-800 text-white flex items-center justify-center shrink-0 mt-0.5">
                      <User className="w-4 h-4" />
                    </div>
                  )}
                </div>
              );
            })}

            {isTyping && (
              <div className="flex items-center gap-2 text-slate-400 text-xs py-1">
                <Bot className="w-4 h-4 text-rose-500 animate-spin" />
                <span>داروساز در حال بررسی تداخلات و نگارش پاسخ...</span>
              </div>
            )}
            <div ref={chatEndRef} />
          </div>

          {/* Medical Disclaimer inside Chat */}
          <div className="bg-amber-50 px-3 py-1.5 border-t border-amber-200 text-[10px] text-amber-800 flex items-center gap-1.5 shrink-0">
            <ShieldAlert className="w-3.5 h-3.5 text-amber-600 shrink-0" />
            <span className="truncate">پاسخ‌های هوش مصنوعی جایگزین ویزیت حضوری پزشک نیست.</span>
          </div>

          {/* Input Bar */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSend();
            }}
            className="p-3 bg-white border-t border-slate-200 flex items-center gap-2"
          >
            <input
              type="text"
              placeholder="سؤال دارویی خود را بپرسید..."
              value={input}
              onChange={(e) => setInput(e.target.value)}
              className="flex-1 bg-slate-100 text-slate-800 text-xs rounded-xl px-3.5 py-2.5 border border-slate-200 focus:outline-hidden focus:border-rose-500 focus:bg-white"
              id="ai-pharmacist-input"
            />
            <button
              type="submit"
              disabled={!input.trim()}
              className="w-10 h-10 rounded-xl bg-rose-600 hover:bg-rose-700 disabled:opacity-40 text-white flex items-center justify-center transition-all cursor-pointer shrink-0"
              id="ai-pharmacist-send-btn"
            >
              <Send className="w-4 h-4 -rotate-90 translate-x-[-1px]" />
            </button>
          </form>
        </div>
      )}
    </>
  );
};
