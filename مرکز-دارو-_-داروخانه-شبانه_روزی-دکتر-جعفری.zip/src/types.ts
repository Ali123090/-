export interface Article {
  id: string;
  slug: string;
  title: string;
  category: string;
  categoryId: string;
  author: string;
  authorRole: string;
  authorAvatar: string;
  date: string;
  readTime: string;
  excerpt: string;
  content: string;
  imageUrl: string;
  commentsCount: number;
  views: number;
  verifiedDoctor: boolean;
  videoUrl?: string;
  tags: string[];
}

export interface Drug {
  id: string;
  nameFa: string;
  nameEn: string;
  genericName: string;
  category: 'Rx' | 'OTC';
  form: string;
  strength: string;
  indications: string;
  dosage: string;
  contraindications: string;
  mechanism: string;
  sideEffects: string;
  manufacturer: string;
}

export interface VideoItem {
  id: string;
  title: string;
  category: string;
  duration: string;
  date: string;
  author: string;
  authorAvatar: string;
  commentsCount: number;
  thumbnail: string;
  videoUrl: string;
  description: string;
}

export interface Interview {
  id: string;
  doctorName: string;
  specialty: string;
  hospital: string;
  avatar: string;
  title: string;
  audioDuration: string;
  excerpt: string;
  audioUrl?: string;
}

export interface OfferProduct {
  id: string;
  name: string;
  brand: string;
  originalPrice: number;
  discountPrice: number;
  discountPercent: number;
  image: string;
  rating: number;
  inStock: boolean;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  iconName: string;
  description: string;
  color: string;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'bot';
  text: string;
  timestamp: string;
  suggestions?: string[];
}
